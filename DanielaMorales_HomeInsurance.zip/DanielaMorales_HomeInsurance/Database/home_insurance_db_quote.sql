CREATE DATABASE  IF NOT EXISTS `home_insurance_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `home_insurance_db`;
-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: home_insurance_db
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quote`
--

DROP TABLE IF EXISTS `quote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `quote` (
  `quote_id` int(11) NOT NULL AUTO_INCREMENT,
  `montly_premium` double NOT NULL,
  `dwelling_coverage` double NOT NULL,
  `detached_structures` double NOT NULL,
  `personal_property` double NOT NULL,
  `additional_expense` double NOT NULL,
  `medical_expense` double NOT NULL,
  `deductible` double NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `homeowner_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  PRIMARY KEY (`quote_id`),
  UNIQUE KEY `quote_id_UNIQUE` (`quote_id`),
  KEY `fk_quote_user_idx` (`user_email`),
  KEY `fk_quote_homeowner_idx` (`homeowner_id`),
  KEY `fk_quote_property_idx` (`property_id`),
  KEY `fk_quote_location_idx` (`location_id`),
  CONSTRAINT `fk_quote_homeowner` FOREIGN KEY (`homeowner_id`) REFERENCES `homeowner` (`homeowner_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_quote_location` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_quote_property` FOREIGN KEY (`property_id`) REFERENCES `property` (`property_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_quoteto_user` FOREIGN KEY (`user_email`) REFERENCES `user` (`email`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote`
--

LOCK TABLES `quote` WRITE;
/*!40000 ALTER TABLE `quote` DISABLE KEYS */;
INSERT INTO `quote` VALUES (55,23.453347999999995,53101.92,5310.192,31861.152,10620.384,5000,1500,'dani@gmail.com',68,56,57),(56,88.74923291666668,199063.7,19906.370000000003,119438.22,39812.740000000005,5000,25489.9,'dani@gmail.com',69,57,58),(57,128.38697916666666,290687.5,29068.75,174412.5,58137.5,5000,35012.3,'dani@gmail.com',70,58,59),(58,90.39101416666666,202746.2,20274.620000000003,121647.72,40549.240000000005,5000,25000,'dani@gmail.com',71,59,60),(60,66.13580833333334,148342,14834.2,89005.2,29668.4,5000,25401.2,'dani@gmail.com',73,61,62);
/*!40000 ALTER TABLE `quote` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-09-04 16:14:59
