

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns={"/","/login"})
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    private String path = null;
    private UserActionRoutes UARoutes = null;
    public MyServlet() {
        super();
        
        // TODO Auto-generated constructor stub
    }
 
    public void init(){
    	UARoutes = new UserActionRoutes();
    	UARoutes.loadErrors();
    }
    
	protected void doGet(HttpServletRequest _req, HttpServletResponse _res) throws ServletException, IOException {
		//Getting my path
		path = _req.getServletPath();
		switch(path) {
			//User views dispatcher
			case "/login": 
				_req.setAttribute("userLoginError", "none");
				UARoutes.getLogin(_req, _res); 
				break;
			case "/registration": 
				_req.setAttribute("userRegistrationError", "none");
				UARoutes.getRegistration(_req, _res); 
				break;
			case "/welcome":
				_req.getRequestDispatcher("./views/welcomeUser.html").forward(_req, _res);
				break;
			case "/home": 
				UARoutes.getHome(_req, _res); 
				break;
			case "/createQuote": 
				try {
					_req.setAttribute("error", "none");
					UARoutes.locationData(_req, _res);
					UARoutes.activateLocation(_req, _res);
					UARoutes.getCreateQuote(_req, _res);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					_res.sendRedirect("./views/serverError.html");
					e.printStackTrace();
				} 
				break;
			case "/getQuote": 
				try {
					UARoutes.getAllQuotes(_req, _res);
					UARoutes.getRetrieveQuote(_req, _res); break;
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					_res.sendRedirect("./views/serverError.html");
					e1.printStackTrace();
				}
			case "/getPolicies": 
				try {
					UARoutes.getAllPolicies(_req, _res);
					UARoutes.getPolicies(_req, _res); break;
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					_res.sendRedirect("./views/serverError.html");
					e1.printStackTrace();
				}
			case "/admin": 
				_req.setAttribute("error", "none");
				UARoutes.getAdmin(_req, _res);break;
			case "/adminHome": 
				_req.setAttribute("adminSearch", "none");
				_req.setAttribute("error", "none");
				UARoutes.getAdminHome(_req, _res);break;	
			case "/logout": 
				UARoutes.getLogout(_req, _res); break;
			case "/quoteSummary": 
				try {
					UARoutes.getMyQuoteSummary(_req, _res);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					_res.sendRedirect("./views/serverError.html");
					e.printStackTrace();
				} break;
			case "/buyPolicy": UARoutes.getBuyPolicy(_req, _res);break;
			case "/adminSearch": 
				try {
					UARoutes.getAllPoliciesAdmin(_req, _res);
				} catch (ClassNotFoundException | SQLException | ParseException e) {
					// TODO Auto-generated catch block
					_res.sendRedirect("./views/serverError.html");
					e.printStackTrace();
				}break;
			case "/renewPolicy": 
				try {
					UARoutes.renewPolicy(_req, _res);
				} catch (ParseException | ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					_res.sendRedirect("./views/serverError.html");
					e.printStackTrace();
				} break;	
			case "/cancelPolicy": 
				try {
					UARoutes.cancelPolicy(_req, _res);
				} catch (ParseException | ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					_res.sendRedirect("./views/serverError.html");
					e.printStackTrace();
				} break;
			default: 
				_req.setAttribute("userLoginError", "none");
				UARoutes.getLogin(_req, _res);
				break;
		}
	}


	protected void doPost(HttpServletRequest _req, HttpServletResponse _res) throws ServletException, IOException {
		path = _req.getServletPath();
		
		switch( path ) {
			case "/login": 
				UARoutes.logIn(_req, _res);break;
			case "/admin": 
				UARoutes.adminLogIn(_req, _res);break;	
			case "/registration": {
				try {
					UARoutes.postRegistration(_req, _res);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} break;
			}
			case "/homeowner": 
				try {
					UARoutes.createLocation(_req, _res);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}break;
			case "/property": 
			UARoutes.createHomeowner(_req, _res);break;
			case "/generateQuote": 
				try {
					UARoutes.generateQuote(_req, _res);
				} catch (ClassNotFoundException | SQLException | ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} break;
			case "/generatePolicy": 
				try {
					UARoutes.getPolicySummary(_req, _res);
				} catch (ClassNotFoundException | SQLException | ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} break;
		}
		
	}

}
 