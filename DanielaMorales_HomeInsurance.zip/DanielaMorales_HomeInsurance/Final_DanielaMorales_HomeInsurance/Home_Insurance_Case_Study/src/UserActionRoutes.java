import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.joda.time.DateTime;
import org.joda.time.Days;

import danielamorales.home_insurance.bo.HomeownerBO;
import danielamorales.home_insurance.bo.LocationBO;
import danielamorales.home_insurance.bo.PolicyBO;
import danielamorales.home_insurance.bo.PropertyBO;
import danielamorales.home_insurance.bo.QuoteBO;
import danielamorales.home_insurance.bo.StateBO;
import danielamorales.home_insurance.bo.UserBO;
import danielamorales.home_insurance.model.Homeowner;
import danielamorales.home_insurance.model.Location;
import danielamorales.home_insurance.model.Policy;
import danielamorales.home_insurance.model.Property;
import danielamorales.home_insurance.model.Quote;
import danielamorales.home_insurance.model.State;
import danielamorales.home_insurance.model.User;

public class UserActionRoutes {
	
	private HttpSession session = null;
	private UserBO u_bo = new UserBO();
	private StateBO s_bo = new StateBO();
	private HomeownerBO ho_bo = new HomeownerBO(); 
	private LocationBO lo_bo = new LocationBO();
	private PropertyBO po_bo = new PropertyBO();
	private PolicyBO policy_bo = new PolicyBO();
	private QuoteBO qu_bo = new QuoteBO();
	private User user = null;
	private Location lo = null;
	private Homeowner ho = null;
	private Property po = null;
	private Quote quote = null;
	HashMap<String, String> errors = new HashMap<String, String>();
	
	/* LOG IN ADMIN*/
	public void adminLogIn(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException {
		//Getting parameters and setting my global object for my class
		if (_req.getParameter("email").isEmpty() || _req.getParameter("password").isEmpty()) {
			displayError(_req, _res, errors.get("emptyForm"));
			_req.setAttribute("error", "block");
			getAdmin(_req, _res);
		} else {
			if ( !(isEmail(_req.getParameter("email") ))){
				displayError(_req, _res, errors.get("notEmail"));
				_req.setAttribute("error", "block");
				getAdmin(_req, _res);
			}else {
				user = new User();
				user.setEmail(_req.getParameter("email"));
				user.setPassword(_req.getParameter("password"));
				try {
					if (u_bo.adminLogIn(user)) {
						//If the user information is correct, then verify if a session exists
						//if it does, delete that session and start a new one.
						session = _req.getSession(false);
						if (session != null) {
							session.invalidate();
						}
						session = _req.getSession(true);
						//After this time of inactivity the session will expire
						session.setMaxInactiveInterval(6000);
						session.setAttribute("currentAdmin", user);
						_req.setAttribute("error", "none");
						_req.setAttribute("adminSearch", "none");
						getAdminHome(_req, _res);
					}else {
						displayError(_req, _res, errors.get("wrongCredentials"));
						_req.setAttribute("error", "block");
						getAdmin(_req, _res);
					}
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					_res.sendRedirect("./views/serverError.html");
				}
			}
		}
	} 
	
	/* LOG IN AND REGISTRATION*/
	public void logIn(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException {
		//Getting parameters and setting my global object for my class
		if (_req.getParameter("email").isEmpty() || _req.getParameter("password").isEmpty()) {
			displayUserError(_req, _res, errors.get("emptyForm"));
			_req.setAttribute("userLoginError", "block");
			getLogin(_req,_res);
		} else {
			if ( !(isEmail(_req.getParameter("email") ))){
				displayUserError(_req, _res, errors.get("notEmail"));
				_req.setAttribute("userLoginError", "block");
				getLogin(_req,_res);
			}else {
				user = new User();
				user.setEmail(_req.getParameter("email"));
				user.setPassword(_req.getParameter("password"));
				user.setAdmin(0);
				try {
					if (u_bo.logIn(user)) {
						//If the user information is correct, then verify if a session exists
						//if it does, delete that session and start a new one.
						session = _req.getSession(false);
						if (session != null) {
							session.invalidate();
						}
						session = _req.getSession();
						//After this time of inactivity the session will expire
						session.setMaxInactiveInterval(6000);
						session.setAttribute("currentUser", user);
						_res.sendRedirect("./home");
					}else {
						displayUserError(_req, _res, errors.get("wrongCredentials"));
						_req.setAttribute("userLoginError", "block");
						getLogin(_req,_res);
					}
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					_res.sendRedirect("./views/serverError.html");
				}
			}
		}
	}  
	
	public void postRegistration(HttpServletRequest _req, HttpServletResponse _res) throws ClassNotFoundException, SQLException, IOException, ServletException {
		String newEmail = _req.getParameter("email-registration");
		String newPassword = _req.getParameter("password-registration");
		String newRpassword = _req.getParameter("rpassword-registration");
		if (newEmail.isEmpty() || newPassword.isEmpty() ||newRpassword.isEmpty() ){
			displayRegistrationError(_req, _res, errors.get("emptyForm"));
			_req.setAttribute("userRegistrationError", "block");
			getRegistration(_req, _res);
		} else {
			if ( !(isEmail(newEmail)) ) {
				displayRegistrationError(_req, _res, errors.get("notEmail"));
				_req.setAttribute("userRegistrationError", "block");
				getRegistration(_req,_res);
			}else {
				if ( !(newPassword.equals(newRpassword)) ) {
					displayRegistrationError(_req, _res, errors.get("passwordUnmatch"));
					_req.setAttribute("userRegistrationError", "block");
					getRegistration(_req,_res);
				}else {
					String pat = "(?=.*\\d)(?=.*[a-zA-Z]).{8,20}";
					if (!(newPassword.matches(pat))) {
						displayRegistrationError(_req, _res, errors.get("passwordFormat"));
						_req.setAttribute("userRegistrationError", "block");
						getRegistration(_req,_res);
					}else {
						user = new User(newEmail, newPassword, 0);
						if (u_bo.registerUser(user) == 0) {
							displayRegistrationError(_req, _res, errors.get("error1"));
							_req.setAttribute("userRegistrationError", "block");
							getRegistration(_req,_res);
						}else {
							_res.sendRedirect("./welcome");
							//_req.getRequestDispatcher("/views/welcomeUser.html").forward(_req, _res);
						}
					}
				}
			}
		}
	}  
	
	/* GET QUOTE POST METHODS*/
	public void createLocation(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException, ClassNotFoundException, SQLException {
		if ( session == null ) {
			_res.sendRedirect("./login");
		}else {
			String rT = _req.getParameter("residenceType");
			String a1 = _req.getParameter("address1");
			String a2 = _req.getParameter("address2");
			String ct = _req.getParameter("city");
			String st = _req.getParameter("state");
			String zp = _req.getParameter("zip");
			String rU = _req.getParameter("residenceUse");
			if ( rT.isEmpty() || a1.isEmpty() || ct.isEmpty() || st.isEmpty() || zp.isEmpty()|| rU.isEmpty()) {
				displayError(_req, _res, errors.get("emptyForm"));
				_req.setAttribute("error", "block");
				activateLocation(_req,_res);
				locationData(_req, _res);
			}else {
				if( !(zp.matches("[0-9]{5}"))) {
					displayError(_req, _res, errors.get("zipFormat"));
					_req.setAttribute("error", "block");
					activateLocation(_req,_res);
					locationData(_req, _res);
				}else {
					lo = new Location();
					lo.setResidence_type(rT);
					lo.setAddress(a1);
					lo.setAddress2(a2);
					lo.setCity(ct);
					lo.setState_id(Integer.parseInt(st));
					lo.setZip(Integer.parseInt(zp));
					lo.setResidence_use(rU);
					lo.setUser_email(user.getEmail());
					_req.setAttribute("error", "none");
					session.setAttribute("location", lo);
					activateHomeowner(_req,_res);
				}
			}
			getCreateQuote(_req,_res);
		}
	}
	
	public void createHomeowner(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException {
		if ( session == null ) {
			_res.sendRedirect("./login");
		}else {
			String fn = _req.getParameter("firstname");
			String ln = _req.getParameter("lastname");
			String bd = _req.getParameter("birthdate");
			String re = _req.getParameter("radioInput");
			String ssn = _req.getParameter("ssn");
			if ( fn.isEmpty() || ln.isEmpty() || bd.isEmpty() || re.isEmpty() || ssn.isEmpty() ) {
				displayError(_req, _res, errors.get("emptyForm"));
				_req.setAttribute("error", "block");
				activateHomeowner(_req,_res);
			}else {
				if ( bd.matches("\\d{4}-\\d{1,2}-\\d{1,2}") &&  ssn.matches("\\d{3}-?\\d{2}-?\\d{4}")) {
					if (isValid(bd)) {
						ho = new Homeowner();
						ho.setFirstname(fn);
						ho.setLastname(ln);
						try {
							ho.setBirthdate(formatDate(bd));
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							displayError(_req, _res, errors.get("dateFormat"));
							_req.setAttribute("error", "block");
							activateHomeowner(_req,_res);
						}
						ho.setRetired(Integer.parseInt(re));
						ho.setSsn(ssn);
						ho.setUser_email(user.getEmail());
						session.setAttribute("homeowner", ho);
						_req.setAttribute("error", "none");
						propertyData(_req,_res);
						activateProperty(_req,_res);
					}else {
						displayError(_req, _res, errors.get("dateFormat"));
						_req.setAttribute("error", "block");
						activateHomeowner(_req,_res);
					}
				}else {
					displayError(_req, _res, errors.get("ssnDateFormat"));
					_req.setAttribute("error", "block");
					activateHomeowner(_req,_res);
				}
			}
			getCreateQuote(_req,_res);
		}
	}
	
	public void generateQuote(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException, ClassNotFoundException, SQLException, ParseException {
		/* FIRST I HAVE TO GET THE PROPERTY PARAMETERS, VALIDATE AND CREATE PROPERTY OBJECT */
		String mV = _req.getParameter("marketValue");
		String yB = _req.getParameter("yearBuilt");
		String sF = _req.getParameter("squareFootage");
		String dS = _req.getParameter("dwellingStyle");
		String sI = _req.getParameter("swimmingInput");
		String rM = _req.getParameter("roofMaterial");
		String gT = _req.getParameter("garageType");
		String bN = _req.getParameter("bathNumber");
		String hBN = _req.getParameter("halfBathNumber");
		if ( mV.isEmpty() || yB.isEmpty() || sF.isEmpty() || dS.isEmpty() || sI.isEmpty() || rM.isEmpty() || gT.isEmpty() || bN.isEmpty() || hBN.isEmpty() ) {
			displayError(_req, _res, errors.get("emptyForm"));
			_req.setAttribute("error", "block");
			propertyData(_req,_res);
			activateProperty(_req,_res);
		}else {
			int date = Calendar.getInstance().get(Calendar.YEAR);
			if ( yB.matches("\\d{4}") && (Integer.parseInt(yB) <= date) &&  mV.matches("^\\d+(?:\\.\\d{1,2})?$") && sF.matches("^\\d+(?:\\.\\d{1,2})?$")) {
				po = new Property();
				po.setProperty_value(Double.parseDouble(mV));
				po.setProperty_year(Integer.parseInt(yB));
				po.setProperty_square(Double.parseDouble(sF));
				po.setDwelling_style(dS);
				po.setSwimming_pool(Integer.parseInt(sI));
				po.setRoof_material(rM);
				po.setGarage_type(gT);
				po.setBaths_number(bN);
				po.setHalf_baths_number(hBN);
				po.setUser_email(user.getEmail());
				session.setAttribute("property", po);
				
				quote = new Quote();
				quote.setUser_email(user.getEmail());
				quote.setHomeowner_id(ho_bo.insertHomeowner(ho));
				quote.setLocation_id(lo_bo.insertLocation(lo));
				po.setLocation_id(quote.getLocation_id());
				quote.setProperty_id(po_bo.insertProperty(po));
				quote = qu_bo.calculation(quote,lo,ho,po);
				quote = qu_bo.insertQuote(quote);
				session.setAttribute("quote", quote);
				_req.setAttribute("error", "none");
				activateDetails(_req,_res);
			}else {
				displayError(_req, _res, errors.get("wrongFormat"));
				_req.setAttribute("error", "block");
				propertyData(_req,_res);
				activateProperty(_req,_res);
			}
		}
		getCreateQuote(_req,_res);
	}
	
	/* GET METHODS */
	
	public void renewPolicy(HttpServletRequest _req, HttpServletResponse _res) throws ParseException, ClassNotFoundException, SQLException, IOException, ServletException {
		Policy p = new Policy();
		DateTime current = new DateTime(); 
		p.setPolicy_key(Integer.parseInt(_req.getParameter("policyToRenew")));
		p.setStart_date(formatDate(current.toString()));
		p.setExpiration_date(formatDate(current.plusYears(1).toDate()));
		policy_bo.renewPolicy(p);
		_req.setAttribute("emailSearched", _req.getParameter("userToSearch"));
		getAllPoliciesAdmin(_req, _res);

	}
	
	public void cancelPolicy(HttpServletRequest _req, HttpServletResponse _res) throws ParseException, ClassNotFoundException, SQLException, IOException, ServletException {
		Policy p = new Policy();
		DateTime current = new DateTime(); 
		p.setPolicy_key(Integer.parseInt(_req.getParameter("policyToCancel")));
		p.setExpiration_date(formatDate(current.toString()));
		p.setActive(false);
		policy_bo.cancelPolicy(p);
		_req.setAttribute("emailSearched", _req.getParameter("userToSearch"));
		getAllPoliciesAdmin(_req, _res);
	}
	
	/* QUOTE SUMMARY METHODS*/
	public void getMyQuoteSummary(HttpServletRequest _req, HttpServletResponse _res) throws ServletException, IOException, ClassNotFoundException, SQLException{
		Quote quoteFound = new Quote();
		Homeowner hoFound = new Homeowner();
		Location loFound = new Location();
		Property proFound = new Property();
		if ( _req.getParameter("myQuote")!= null ) {
			/* ONE CALL TO A JOIN SELECT COULD BE A BETTER OPTION
			 * FOR TIME SAVING AND OPTIMIZATION HOWEVER
			 * THIS WAY I CAN HAVE EVERY OBJECT INDEPENDENTLY AND ITS
			 * EASIER TO HANDLE ALL THE DATA*/
			quoteFound = qu_bo.getQuote(Integer.parseInt(_req.getParameter("myQuote")));
			hoFound = ho_bo.getHomeowner(quoteFound.getHomeowner_id());
			loFound = lo_bo.getLocation(quoteFound.getLocation_id());
			proFound = po_bo.getProperty(quoteFound.getProperty_id());
			_req.setAttribute("quoteFound", quoteFound);
			_req.setAttribute("homeownerFound", hoFound);
			_req.setAttribute("propertyFound", proFound);
			_req.setAttribute("locationFound", loFound);
			activateQuoteSummary(_req,_res);
			getQuoteSummary(_req, _res);
		}

	}
	
	public void getBuyPolicy(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException {
		Integer quoteID = Integer.parseInt(_req.getParameter("quoteIDToBuy"));
		_req.setAttribute("quoteIDToBuy", quoteID);
		_req.setAttribute("error", "none");
		activateBuyPolicy(_req, _res);
		getQuoteSummary(_req, _res);
	}
	
	public void getPolicySummary(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException, ClassNotFoundException, SQLException, ParseException {
		Integer quoteID = Integer.parseInt(_req.getParameter("quoteIDBought"));
		String startDate = _req.getParameter("startDate");
		if( !(startDate.isEmpty())) {
			if (isValid(startDate)) {  
				DateTime start = new DateTime(startDate);
				DateTime current = new DateTime();
				Integer days = Math.abs(Days.daysBetween(start, current).getDays());
				if(days < 60 && start.isAfter(current)) {
					Policy p = new Policy();
					p.setActive(true);
					p.setPolicy_term(1);
					p.setQuote_id(quoteID);
					p.setStart_date(formatDate(startDate));
					p.setExpiration_date(formatDate(start.plusYears(1).toDate()));
					p.setUser_email(user.getEmail());
					p.setPolicy_key(policy_bo.insertPolicy(p));
					session.setAttribute("policy", p);
					activatePolicySummary(_req, _res);
				}else {
					displayError(_req, _res, errors.get("dateValidPeriod"));
					_req.setAttribute("error", "block");
					_req.setAttribute("quoteIDToBuy", quoteID);
					activateBuyPolicy(_req, _res);
				}
			}else {
				displayError(_req, _res, errors.get("datePeriod"));
				_req.setAttribute("error", "block");
				_req.setAttribute("quoteIDToBuy", quoteID);
				activateBuyPolicy(_req, _res);
			}
		}else {
			displayError(_req, _res, errors.get("emptyForm"));
			_req.setAttribute("error", "block");
			_req.setAttribute("quoteIDToBuy", quoteID);
			activateBuyPolicy(_req, _res);
		}
		getQuoteSummary(_req, _res);
	}
	
	/* QUOTE SUMMARY*/
	public void getQuoteSummary(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException {
		session = _req.getSession(false);
		if ( session != null ) {
			_req.getRequestDispatcher("/views/user/policy.jsp").forward(_req, _res);
		}else {
			displayUserError(_req, _res, errors.get("sessionExpired"));
			_req.setAttribute("userLoginError", "block");
			getLogin(_req,_res);
		}
	}  
	
	/* HOME PAGE*/
	public void getHome(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException {
		session = _req.getSession(false);
		if ( session != null) {
			_req.getRequestDispatcher("/views/user/home.jsp").forward(_req, _res);
		}else {
			displayUserError(_req, _res, errors.get("sessionExpired"));
			_req.setAttribute("userLoginError", "block");
			getLogin(_req,_res);
		}
	}  
	
	public void getCreateQuote(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException {
		session = _req.getSession(false);
		if ( session != null ) {
			_req.getRequestDispatcher("/views/user/createQuote.jsp").forward(_req, _res);
		}else {
			displayUserError(_req, _res, errors.get("sessionExpired"));
			_req.setAttribute("userLoginError", "block");
			getLogin(_req,_res);
		}
	}  
	
	public void getRetrieveQuote(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException {
		session = _req.getSession(false);
		if ( session != null ) {
			_req.getRequestDispatcher("/views/user/retrieveQuote.jsp").forward(_req, _res);
		}else {
			displayUserError(_req, _res, errors.get("sessionExpired"));
			_req.setAttribute("userLoginError", "block");
			getLogin(_req,_res);
		}
	}
	
	public void getPolicies(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException {
		session = _req.getSession(false);
		if ( session != null ) {
			_req.getRequestDispatcher("/views/user/policies.jsp").forward(_req, _res);
		}else {
			displayUserError(_req, _res, errors.get("sessionExpired"));
			_req.setAttribute("userLoginError", "block");
			getLogin(_req,_res);
		}
	}
	
	public void getLogin(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException {
		_req.getRequestDispatcher("/views/user/login.jsp").forward(_req, _res);
	}  
	
	public void getRegistration(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException {
		_req.getRequestDispatcher("/views/user/registration.jsp").forward(_req, _res);
	}  
	
	public void getLogout(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException {
		if ( session != null) {
			session.invalidate();
		}
		_req.setAttribute("userLoginError", "none");
		getLogin(_req,_res);
	}  
	/*ADMIN*/
	public void getAdmin(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException {
		_req.getRequestDispatcher("/views/admin/login.jsp").forward(_req, _res);
	} 
	
	public void getAdminHome(HttpServletRequest _req, HttpServletResponse _res) throws IOException, ServletException {
		_req.getRequestDispatcher("/views/admin/home.jsp").forward(_req, _res);
	} 
	
	/* FUNCTIONS */
	public boolean isEmail(String s) {
        return s.matches("^[-0-9a-zA-Z.+_]+@[-0-9a-zA-Z.+_]+\\.[a-zA-Z]{2,4}");
    }
	
	public boolean isValid(String date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    dateFormat.setLenient(false);
	    try {
	      dateFormat.parse(date.trim());
	    } catch (Exception pe) {
	    	return false;
	    }
	    return true;	
	}
	
	public java.sql.Date formatDate(String d) throws ParseException{
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date parsed = format.parse(d);
        java.sql.Date sql = new java.sql.Date(parsed.getTime());
		return sql;
	}
	
	public java.sql.Date formatDate(Date d) throws ParseException{
        java.sql.Date sql = new java.sql.Date(d.getTime());
		return sql;
	}
	
	/* SHOWING SECTIONS - GET QUOTE PAGE */
	public void activateLocation(HttpServletRequest _req, HttpServletResponse _res){
		_req.setAttribute("location", "block"); 
		_req.setAttribute("homeowner", "none"); 
		_req.setAttribute("property", "none");
		_req.setAttribute("details", "none");
	}
	
	public void activateHomeowner(HttpServletRequest _req, HttpServletResponse _res){
		_req.setAttribute("location", "none"); 
		_req.setAttribute("homeowner", "block"); 
		_req.setAttribute("property", "none");
		_req.setAttribute("details", "none");
		_req.setAttribute("policy", "none");
	}
	
	public void activateProperty(HttpServletRequest _req, HttpServletResponse _res){
		_req.setAttribute("location", "none"); 
		_req.setAttribute("homeowner", "none"); 
		_req.setAttribute("property", "block");
		_req.setAttribute("details", "none");
	}
	
	public void activateDetails(HttpServletRequest _req, HttpServletResponse _res){
		_req.setAttribute("location", "none"); 
		_req.setAttribute("homeowner", "none"); 
		_req.setAttribute("property", "none");
		_req.setAttribute("details", "block");
	}
	
	/* SHOWING SECTIONS - QUOTE SUMMARY */
	public void activateQuoteSummary(HttpServletRequest _req, HttpServletResponse _res){
		_req.setAttribute("quoteSummary", "block"); 
		_req.setAttribute("buyPolicy", "none"); 
		_req.setAttribute("policySummary", "none");
	}
	public void activateBuyPolicy(HttpServletRequest _req, HttpServletResponse _res){
		_req.setAttribute("quoteSummary", "none"); 
		_req.setAttribute("buyPolicy", "block"); 
		_req.setAttribute("policySummary", "none");
	}
	public void activatePolicySummary(HttpServletRequest _req, HttpServletResponse _res){
		_req.setAttribute("quoteSummary", "none"); 
		_req.setAttribute("buyPolicy", "none"); 
		_req.setAttribute("policySummary", "block");
	}
	
	/*GET ALL "QUOTES"*/
	public void getAllQuotes(HttpServletRequest _req, HttpServletResponse _res) throws ClassNotFoundException, SQLException, IOException, ServletException {
		session = _req.getSession(false);
		if (session!=null) {
			HashMap <Location, HashMap<Quote, State>> myRetrievedList = new HashMap <Location, HashMap<Quote, State>>();
			myRetrievedList = lo_bo.getAllLocations(user.getEmail());
			_req.setAttribute("retrievedList", myRetrievedList);
		}else {
			displayUserError(_req, _res, errors.get("sessionExpired"));
			_req.setAttribute("userLoginError", "block");
			getLogin(_req,_res);
		}
	}
	
	/*GET POLICIES */
	public void getAllPolicies(HttpServletRequest _req, HttpServletResponse _res) throws ClassNotFoundException, SQLException, IOException, ServletException {
		session = _req.getSession(false);
		if (session!=null) {
			List<Policy> myRetrievedList = new ArrayList<Policy>();
			myRetrievedList = policy_bo.getAllPolicies(user.getEmail());
			_req.setAttribute("retrievedListPolicies", myRetrievedList);
		}else {
			displayUserError(_req, _res, errors.get("sessionExpired"));
			_req.setAttribute("userLoginError", "block");
			getLogin(_req,_res);
		}
	}
	
	/*ADMIN GET POLICIES */
	public void getAllPoliciesAdmin(HttpServletRequest _req, HttpServletResponse _res) throws ClassNotFoundException, SQLException, IOException, ServletException, ParseException {
		session = _req.getSession(false);
		if (session!=null) {
			String u = null;
			if ( _req.getParameter("userToSearch") == null ) {
				u = (String) _req.getAttribute("emailSearched");
			}else {
				u = _req.getParameter("userToSearch");
			}	
			if ( u.isEmpty() ) {
				displayError(_req, _res, errors.get("emptyForm"));
				_req.setAttribute("adminSearch", "none");
				_req.setAttribute("error", "block");
				getAdminHome(_req,_res);
			}else {
				List<Policy> myRetrievedList = new ArrayList<Policy>();
				myRetrievedList = policy_bo.getAllPolicies(u);
				Date date = new Date();
				for ( Policy p: myRetrievedList ) {
					if ( p.getRenewalDate().equals(formatDate(date)) || formatDate(date).after(p.getRenewalDate()) ){
						p.setRenewable(true);
					}else {
						p.setRenewable(false);
					}
				}
				_req.setAttribute("retrievedListPolicies", myRetrievedList);
				_req.setAttribute("adminSearch", "block");
				_req.setAttribute("error", "none");
				getAdminHome(_req,_res);
			}
		}else {
			adminLogIn(_req,_res);
		}
	}
	
	/* DATA TO USE */
	public void locationData(HttpServletRequest _req, HttpServletResponse _res) throws ClassNotFoundException, SQLException, IOException {
		/* IF I HAVE TIME I SHOULD READ THIS FROM A FILE SO THE DATA CAN BE UPDATED WITHOUT TOUCHING THE CODE*/
		List<String> rT = new ArrayList<String>();
		rT.add(new String("Single-Family Home"));
		rT.add(new String("Condo"));
		rT.add(new String("Townhouse"));
		rT.add(new String("Rowhouse"));
		rT.add(new String("Duplex"));
		rT.add(new String("Apartment"));
		_req.setAttribute("residenceType", rT);
		
		List<String> rU = new ArrayList<String>();
		rU.add(new String("Primary"));
		rU.add(new String("Secondary"));
		rU.add(new String("Rental Property"));
		_req.setAttribute("residenceUse", rU);
		
		List<State> states = s_bo.allStates();
		_req.setAttribute("states", states);
	}
	
	public void propertyData(HttpServletRequest _req, HttpServletResponse _res) {
		List<String> dS = new ArrayList<String>();
		dS.add(new String("1 Story"));
		dS.add(new String("1.5 Story"));
		dS.add(new String("2 Story"));
		dS.add(new String("2.5 Story"));
		dS.add(new String("3 Story"));
		_req.setAttribute("dwelling", dS);
		
		List<String> rM = new ArrayList<String>();
		rM.add(new String("Concrete"));
		rM.add(new String("Clay"));
		rM.add(new String("Rubber"));
		rM.add(new String("Steel"));
		rM.add(new String("Tin"));
		rM.add(new String("Wood"));
		_req.setAttribute("roof", rM);
		
		List<String> tG = new ArrayList<String>();
		tG.add(new String("Attached"));
		tG.add(new String("Detached"));
		tG.add(new String("Basement"));
		tG.add(new String("Built-in"));
		tG.add(new String("None"));
		_req.setAttribute("garage", tG);
		
		List<String> nB = new ArrayList<String>();
		nB.add(new String("1"));
		nB.add(new String("2"));
		nB.add(new String("3"));
		nB.add(new String("More"));
		_req.setAttribute("baths", nB);
		
		List<String> nHB = new ArrayList<String>();
		nHB.add(new String("1"));
		nHB.add(new String("2"));
		nHB.add(new String("3"));
		nHB.add(new String("More"));
		_req.setAttribute("halfBaths", nHB);
	}
	
	public void loadErrors() {
		errors.put("emptyForm", "Oops! Some inputs can't be empty");
		errors.put("notEmail", "Oops! Enter a valid email");
		errors.put("wrongCredentials", "Oops! Wrong credentials");
		errors.put("passwordUnmatch", "Oops! Passwords have to match");
		errors.put("passwordFormat", "Oops! Password has to be alphanumeric");
		errors.put("sessionExpired", "Oops! Session expired, log in again");
		errors.put("error1", "Oops! Looks like that user already exists");
		errors.put("zipFormat", "Oops! Zip code is numeric and has a format");
		errors.put("dateFormat", "Oops! Make sure the date is in the right format");
		errors.put("ssnDateFormat", "Oops! Make sure the date and ssn are in the right format");
		errors.put("wrongFormat", "Oops! Make sure the values are in the right format");
		errors.put("someError", "Oops! Something went wrong, try later");
		errors.put("datePeriod", "Oops! Make sure your date is correct");
		errors.put("dateValidPeriod", "Oops! Make sure your date is less than 60 days from now");
	}
	
	public void displayUserError(HttpServletRequest _req, HttpServletResponse _res, String _err ) {
		_req.setAttribute("userLoginErrorToDisplay", _err);
	}
	
	public void displayRegistrationError(HttpServletRequest _req, HttpServletResponse _res, String _err ) {
		_req.setAttribute("userRegistrationErrorToDisplay", _err);
	}
	
	public void displayError(HttpServletRequest _req, HttpServletResponse _res, String _err ) {
		_req.setAttribute("errorToDisplay", _err);
	}
}
