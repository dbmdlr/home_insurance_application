package danielamorales.home_insurance.bo;

import java.io.IOException;
import java.sql.SQLException;

import danielamorales.home_insurance.dao.HomeownerDAO;
import danielamorales.home_insurance.model.Homeowner;

public class HomeownerBO {
	private HomeownerDAO ho_dao = new HomeownerDAO();
	
	public Integer insertHomeowner(Homeowner ho) throws ClassNotFoundException, SQLException, IOException {
		return ho_dao.postHomeowner(ho);
	}
	
	public Homeowner getHomeowner(Integer _id) throws ClassNotFoundException, SQLException, IOException {
		return ho_dao.getHomeowner(_id);
	}
}
