package danielamorales.home_insurance.bo;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;

import danielamorales.home_insurance.dao.LocationDAO;
import danielamorales.home_insurance.model.Location;
import danielamorales.home_insurance.model.Quote;
import danielamorales.home_insurance.model.State;

public class LocationBO {
	/* THIS BO ITS REDUNDANT BUT...*/
	private LocationDAO lo_dao = new LocationDAO();
	
	public Integer insertLocation(Location lo) throws ClassNotFoundException, SQLException, IOException {
		return lo_dao.postLocation(lo);
	}
	
	public Location getLocation(Integer _id) throws ClassNotFoundException, SQLException, IOException {
		return lo_dao.getLocation(_id);
	}
	
	public HashMap <Location, HashMap<Quote, State>> getAllLocations(String _email) throws ClassNotFoundException, SQLException, IOException {
		return lo_dao.getAllLocations(_email);
	}
}
