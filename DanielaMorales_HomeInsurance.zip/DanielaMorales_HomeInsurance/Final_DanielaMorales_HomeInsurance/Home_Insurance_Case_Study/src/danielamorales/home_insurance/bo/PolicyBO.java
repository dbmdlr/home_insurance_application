package danielamorales.home_insurance.bo;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import danielamorales.home_insurance.dao.PolicyDAO;
import danielamorales.home_insurance.model.Policy;

public class PolicyBO {
	private PolicyDAO po_dao = new PolicyDAO();
	
	public Integer insertPolicy(Policy p) throws ClassNotFoundException, SQLException, IOException {
		return po_dao.postPolicy(p);
	}
	
	public List<Policy> getAllPolicies(String _email) throws ClassNotFoundException, SQLException, IOException{
		return po_dao.getAllPolicies(_email);
	}
	
	public Boolean renewPolicy(Policy p) throws ClassNotFoundException, SQLException, IOException {
		return po_dao.renewPolicy(p);
	}
	
	public Boolean cancelPolicy(Policy p) throws ClassNotFoundException, SQLException, IOException {
		return po_dao.cancelPolicy(p);
	}
}
