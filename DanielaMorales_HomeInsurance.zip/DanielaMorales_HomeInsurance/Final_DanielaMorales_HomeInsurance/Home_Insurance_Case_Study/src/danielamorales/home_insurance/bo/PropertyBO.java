package danielamorales.home_insurance.bo;

import java.io.IOException;
import java.sql.SQLException;

import danielamorales.home_insurance.dao.PropertyDAO;
import danielamorales.home_insurance.model.Property;

public class PropertyBO {
	private PropertyDAO po_dao = new PropertyDAO();
	
	public Integer insertProperty(Property po) throws ClassNotFoundException, SQLException, IOException {
		return po_dao.postProperty(po);
	}
	
	public Property getProperty(Integer _id) throws ClassNotFoundException, SQLException, IOException {
		return po_dao.getProperty(_id);
	}
}
