package danielamorales.home_insurance.bo;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.Years;

import danielamorales.home_insurance.dao.QuoteDAO;
import danielamorales.home_insurance.model.Homeowner;
import danielamorales.home_insurance.model.Location;
import danielamorales.home_insurance.model.Property;
import danielamorales.home_insurance.model.Quote;

public class QuoteBO {
	private QuoteDAO q_dao = new QuoteDAO();
	
	public Quote insertQuote(Quote q) throws ClassNotFoundException, SQLException, IOException {
		q.setQuote_id(q_dao.postQuote(q));
		return q;	
	}
	
	public Quote getQuote(Integer _id) throws ClassNotFoundException, SQLException, IOException {
		return 	q_dao.getQuote(_id);	
	}
	
	public List<Quote> getAllQuotes(String _email) throws ClassNotFoundException, SQLException, IOException {
		return 	q_dao.getAllQuotes(_email);	
	}
	
	public Quote calculation(Quote q, Location lo, Homeowner ho, Property po) {
		q.setMedical_expense((double) 5000);
		q.setDeductible(po.getProperty_value()*0.1);
		q.setDwelling_coverage(calculateDwellingCoverage(po.getProperty_square(), po.getProperty_year(), po.getProperty_value()));
		q.setDetached_structures(q.getDwelling_coverage()*0.10);
		q.setPersonal_property(q.getDwelling_coverage()*0.60);
		q.setAdditional_expense(q.getDwelling_coverage()*0.20);
		q.setMontly_premium(calculateMontlyPremium(q.getDwelling_coverage(), lo.getResidence_type()));
		return q;
	}
	
	private Double calculateDwellingCoverage(Double squareFootage, Integer homeYear, Double marketValue) {
		Double costPerSq = 120.00;
		Double homeValue = squareFootage * costPerSq;
		DateTime houseYear = new DateTime(homeYear+"-01-01");
		DateTime current = new DateTime();
		Integer yearsOld = Years.yearsBetween(houseYear, current).getYears();
		Double percentage = 0.0;
		Double dwelling = 0.0;
		
		if( yearsOld < 5 ) {
			percentage = 0.1;
		}
		if( yearsOld < 10 ) {
			percentage = 0.2;
		}
		if( yearsOld < 20 ) {
			percentage = 0.3;
		}
		if( yearsOld > 20 ) {
			percentage = 0.5;
		}
		homeValue = homeValue - (homeValue*percentage);
		dwelling = homeValue + (0.50*marketValue);
		return dwelling;
	}
	
	private Double calculateMontlyPremium(Double dwelling, String homeType) {
		Double rate = (5/1000.00);
		Double premium = rate * dwelling;
		Double percentage = 0.0;
		if (homeType.equals("Single-Family Home")) {
			percentage = 0.5;
		}
		if ( homeType.equals("Condo") || homeType.equals("Apartment") || homeType.equals("Duplex")) {
			percentage = 0.06;
		}
		if( homeType.equals("Townhouse") || homeType.equals("Rowhouse") ) {
			percentage = 0.07;
		}
		premium = (premium + (percentage*premium))/12;
		return premium;
	}
}
