package danielamorales.home_insurance.bo;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import danielamorales.home_insurance.dao.StateDAO;
import danielamorales.home_insurance.model.State;

public class StateBO {
	private StateDAO s_dao = new StateDAO();
	
	public List<State> allStates() throws ClassNotFoundException, SQLException, IOException{
		return s_dao.getAllState();		
	}
}
