package danielamorales.home_insurance.bo;

import java.io.IOException;
import java.sql.SQLException;

import danielamorales.home_insurance.dao.UserDAO;
import danielamorales.home_insurance.model.User;

public class UserBO {
	
	public int registerUser(User u) throws SQLException, IOException, ClassNotFoundException{
		UserDAO u_dao = new UserDAO();
		int ID = u_dao.registerUser(u);
		return ID;
	}
	
	public Boolean logIn(User u) throws SQLException, IOException, ClassNotFoundException{
		UserDAO u_dao = new UserDAO();
		return u_dao.logIn(u);
	}
	
	public Boolean adminLogIn(User u) throws SQLException, IOException, ClassNotFoundException{
		UserDAO u_dao = new UserDAO();
		return u_dao.adminLogIn(u);
	}
	
}
