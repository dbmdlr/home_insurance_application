package danielamorales.home_insurance.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import danielamorales.home_insurance.model.Homeowner;

public class HomeownerDAO {
	private Connection conn = null;
	private Statement stmt = null; // query
	private PreparedStatement pStmt = null; // query
	private ResultSet rs = null; //return the rows
	private Integer result = 0;
	
	public Integer postHomeowner(Homeowner h) throws ClassNotFoundException, SQLException, IOException{
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			String query = "INSERT INTO homeowner VALUES(null, '"+h.getFirstname()+"', '"+h.getLastname()+"', "
					+ "'"+h.getBirthdate()+"', "+h.getRetired()+", "
							+ "'"+h.getSsn()+"', '"+h.getUser_email()+"');";
			pStmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
			pStmt.executeUpdate();
			rs = pStmt.getGeneratedKeys();
			 
			if (rs.next()) {
				return rs.getInt(1);
			}
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return null;
	}
	
	public Homeowner getHomeowner(Integer _id) throws ClassNotFoundException, SQLException, IOException{
		Homeowner h = null;
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			stmt = conn.createStatement();//creating the statement to send the query
			String query = "SELECT * FROM homeowner WHERE homeowner_id='"+_id+"';";
			rs = stmt.executeQuery(query);
			
			if ( rs.next() ) {
				h = new Homeowner();
				h.setHomeowner_id(rs.getInt(1));
				h.setFirstname(rs.getString(2));
				h.setLastname(rs.getString(3));
				h.setBirthdate(rs.getDate(4));
				h.setRetired(rs.getInt(5));
				h.setSsn(rs.getString(6));
				h.setUser_email(rs.getString(7));
				return h;
			}
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return null;
	}
	
	//UPDATE
	public Boolean putHomeowner(Homeowner h) throws ClassNotFoundException, SQLException, IOException{
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			String query = "UPDATE homeowner SET firstname='"+h.getFirstname()+"', lastname='"+h.getLastname()+"', "
					+ "birthdate='"+h.getBirthdate()+"', retired="+h.getRetired()+", "
							+ "ssn='"+h.getSsn()+"' WHERE user_email='"+h.getUser_email()+"';";
			stmt = conn.createStatement();
			result = stmt.executeUpdate(query);
			
			if (result>0) {
				return true;
			}
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return false;
	}
	
}
