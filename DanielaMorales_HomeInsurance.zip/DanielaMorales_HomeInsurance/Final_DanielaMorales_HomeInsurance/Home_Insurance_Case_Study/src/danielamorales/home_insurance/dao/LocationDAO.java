package danielamorales.home_insurance.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import danielamorales.home_insurance.model.Location;
import danielamorales.home_insurance.model.Quote;
import danielamorales.home_insurance.model.State;

public class LocationDAO {
	private Connection conn = null;
	private Statement stmt = null; // query
	private PreparedStatement pStmt = null; // query
	private ResultSet rs = null; //return the rows
	
	public Integer postLocation(Location lo) throws ClassNotFoundException, SQLException, IOException{
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			String query = "INSERT INTO location VALUES(null, '"+lo.getAddress()+"', '"+lo.getAddress2()+"', "
					+ "'"+lo.getCity()+"', "+lo.getState_id()+", "
							+ ""+lo.getZip()+", '"+lo.getResidence_type()+"', '"+lo.getResidence_use()+"', '"+lo.getUser_email()+"');";
			pStmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
			pStmt.executeUpdate();
			rs = pStmt.getGeneratedKeys();
			
			if (rs.next()) {
				return rs.getInt(1);
			}
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return null;
	}
	
	public Location getLocation(Integer _id) throws ClassNotFoundException, SQLException, IOException{
		Location lo = null;
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			stmt = conn.createStatement();//creating the statement to send the query
			String query = "SELECT * FROM location INNER JOIN state ON location.state = state.state_id WHERE location_id="+_id+";";
			rs = stmt.executeQuery(query);
			
			if ( rs.next() ) {
				lo = new Location();
				lo.setAddress(rs.getString(2));
				lo.setAddress2(rs.getString(3));
				lo.setCity(rs.getString(4));
				lo.setState_id(rs.getInt(5));
				lo.setZip(rs.getInt(6));
				lo.setResidence_type(rs.getString(7));
				lo.setResidence_use(rs.getString(8));
				lo.setUser_email(rs.getString(9));
				lo.setState(rs.getString(12));
				return lo;
			}
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return null;
	}
	
	/* JOIN METHOD*/
	public HashMap<Location, HashMap<Quote, State>> getAllLocations(String _email) throws ClassNotFoundException, SQLException, IOException{
		Location lo = null;
		Quote qu = null;
		State st = null;
		HashMap <Location, HashMap<Quote, State>> outer = new HashMap<Location, HashMap<Quote, State>>();
		HashMap<Quote, State> inner = new HashMap<Quote, State>();
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			stmt = conn.createStatement();//creating the statement to send the query
			String query = "SELECT " + 
					"lo.location_id, " + 
					"lo.address, " + 
					"lo.address2, " + 
					"lo.city, " + 
					"lo.zip, " + 
					"lo.residence_type, " + 
					"lo.residence_use, " +
					"st.name, "+
					"qu.location_id,"+
					"qu.quote_id " + 
					"FROM location lo " + 
					"INNER JOIN quote qu " + 
					"ON lo.location_id=qu.location_id " + 
					"INNER JOIN state st " + 
					"ON lo.state=st.state_id " + 
					"WHERE lo.user_email='"+_email+"' AND qu.quote_id NOT IN(SELECT quote_id FROM policy) ORDER BY qu.quote_id DESC;";
			rs = stmt.executeQuery(query);
			
			while ( rs.next() ) {
				lo = new Location();
				lo.setLocation_id(rs.getInt(1));
				lo.setAddress(rs.getString(2));
				lo.setAddress2(rs.getString(3));
				lo.setCity(rs.getString(4));
				lo.setState_id(rs.getInt(9));
				lo.setZip(rs.getInt(5));
				lo.setResidence_type(rs.getString(6));
				lo.setResidence_use(rs.getString(7));
				st = new State();
				st.setState_name(rs.getString(8));
				qu = new Quote();
				qu.setLocation_id(rs.getInt(9));
				qu.setQuote_id(rs.getInt(10));
				inner.put(qu, st);
				outer.put(lo, inner);
			}
			return outer;
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return null;
	}
	
}
