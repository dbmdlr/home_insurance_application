package danielamorales.home_insurance.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;

import danielamorales.home_insurance.model.Policy;

public class PolicyDAO {
	private Connection conn = null;
	private Statement stmt = null; // query
	private PreparedStatement pStmt = null; // query
	private ResultSet rs = null; //return the rows
	
	public Integer postPolicy(Policy p) throws ClassNotFoundException, SQLException, IOException{
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			String query = "INSERT INTO policy VALUES(null, '"+p.getStart_date()+"', '"+p.getExpiration_date()+"', "
					+ p.getPolicy_term()+", "+p.getActive()+", "
							+p.getQuote_id()+",'"+p.getUser_email()+"');";
			pStmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
			pStmt.executeUpdate();
			rs = pStmt.getGeneratedKeys();
			
			if (rs.next()) {
				return rs.getInt(1);
			}
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return null;
	}
	
	public Policy getPolicy(Integer _id) throws ClassNotFoundException, SQLException, IOException{
		Policy p = null;
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			stmt = conn.createStatement();//creating the statement to send the query
			String query = "SELECT * FROM policy WHERE quote_id='"+_id+"';";
			rs = stmt.executeQuery(query);
			
			if ( rs.next() ) {
				p = new Policy();
				p.setPolicy_key(_id);
				p.setStart_date(rs.getDate(2));
				p.setExpiration_date(rs.getDate(3));
				p.setPolicy_term(rs.getInt(4));
				p.setActive(rs.getBoolean(5));
				p.setQuote_id(rs.getInt(6));
				p.setUser_email(rs.getString(7));
				return p;
			}
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return null;
	}
	
	public List<Policy> getAllPolicies(String _email) throws ClassNotFoundException, SQLException, IOException{
		List<Policy> pList = null;
		Policy p = null;
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			stmt = conn.createStatement();//creating the statement to send the query
			String query = "SELECT * FROM policy WHERE user_email='"+_email+"';";
			rs = stmt.executeQuery(query);
			
			pList = new ArrayList<Policy>();
			
			while ( rs.next() ) {
				p = new Policy();
				p.setPolicy_key(rs.getInt(1));
				p.setStart_date(rs.getDate(2));
				p.setExpiration_date(rs.getDate(3));
				p.setPolicy_term(rs.getInt(4));
				p.setActive(rs.getBoolean(5));
				p.setQuote_id(rs.getInt(6));
				p.setUser_email(rs.getString(7));
				
				DateTime date = new DateTime(p.getExpiration_date());
				Date a = date.minusDays(30).toDate();
				java.sql.Date sql = new java.sql.Date(a.getTime());
				
				p.setRenewalDate(sql);
				pList.add(p);
			}
			return pList;
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return null;
	}
	
	public Boolean renewPolicy(Policy p) throws ClassNotFoundException, SQLException, IOException{
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			Integer result = 0;
			String query = "UPDATE policy SET start_date='"+p.getStart_date()+"', status=true, expiration_date='"+p.getExpiration_date()+"' "
					+ "WHERE policy_key="+p.getPolicy_key()+";";
			pStmt = conn.prepareStatement(query);
			result = pStmt.executeUpdate();
			
			if (result > 0) {
				return true;
			}
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return false;
	}
	
	public Boolean cancelPolicy(Policy p) throws ClassNotFoundException, SQLException, IOException{
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			Integer result = 0;
			String query = "UPDATE policy SET expiration_date='"+p.getExpiration_date()+"', status="+p.getActive()+" "
					+ "WHERE policy_key="+p.getPolicy_key()+";";
			pStmt = conn.prepareStatement(query);
			result = pStmt.executeUpdate();
			
			if (result > 0) {
				return true;
			}
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return false;
	}
}
