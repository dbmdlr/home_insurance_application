package danielamorales.home_insurance.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import danielamorales.home_insurance.model.Property;

public class PropertyDAO {
	private Connection conn = null;
	private Statement stmt = null; // query
	private PreparedStatement pStmt = null; // query
	private ResultSet rs = null; //return the rows
	
	public Integer postProperty(Property p) throws ClassNotFoundException, SQLException, IOException{
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			String query = "INSERT INTO property VALUES(null, "+p.getProperty_year()+", "+p.getProperty_square()+", "
					+ "'"+p.getRoof_material()+"', '"+p.getGarage_type()+"', "
							+ "'"+p.getBaths_number()+"', '"+p.getHalf_baths_number()+"', "+p.getSwimming_pool()+", "
									+ "'"+p.getDwelling_style()+"', '"+p.getUser_email()+"', "+p.getLocation_id()+","+p.getProperty_value()+");";
			pStmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
			pStmt.executeUpdate();
			rs = pStmt.getGeneratedKeys();
			
			if (rs.next()) {
				return rs.getInt(1);
			}
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return null;
	}
	
	public Property getProperty(Integer _id) throws ClassNotFoundException, SQLException, IOException{
		Property pro = null;
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			stmt = conn.createStatement();//creating the statement to send the query
			String query = "SELECT * FROM property WHERE property_id='"+_id+"';";
			rs = stmt.executeQuery(query);
			
			if ( rs.next() ) {
				pro = new Property();
				pro.setProperty_year(rs.getInt(2));
				pro.setProperty_square(rs.getDouble(3));
				pro.setRoof_material(rs.getString(4));
				pro.setGarage_type(rs.getString(5));
				pro.setBaths_number(rs.getString(6));
				pro.setHalf_baths_number(rs.getString(7));
				pro.setSwimming_pool(rs.getInt(8));
				pro.setDwelling_style(rs.getString(9));
				pro.setUser_email(rs.getString(10));
				pro.setLocation_id(rs.getInt(11));
				pro.setProperty_value(rs.getDouble(12));
				return pro;
			}
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return null;
	}
}
