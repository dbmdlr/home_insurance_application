package danielamorales.home_insurance.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import danielamorales.home_insurance.model.Quote;

public class QuoteDAO {
	private Connection conn = null;
	private Statement stmt = null; // query
	private PreparedStatement pStmt = null; // query
	private ResultSet rs = null; //return the rows
	
	public QuoteDAO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer postQuote(Quote q) throws ClassNotFoundException, SQLException, IOException{
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			String query = "INSERT INTO quote VALUES(null, "+q.getMontly_premium()+", "+q.getDwelling_coverage()+", "
					+ q.getDetached_structures()+", "+q.getPersonal_property()+", "
							+q.getAdditional_expense()+", "+q.getMedical_expense()+", "+q.getDeductible()+", "
									+ "'"+q.getUser_email()+"', "+q.getHomeowner_id()+", "+q.getProperty_id()+", "+q.getLocation_id()+");";
			pStmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
			pStmt.executeUpdate();
			rs = pStmt.getGeneratedKeys();
			
			if (rs.next()) {
				return rs.getInt(1);
			}
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return null;
	}
	
	public Quote getQuote(Integer _id) throws ClassNotFoundException, SQLException, IOException{
		Quote q = null;
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			stmt = conn.createStatement();//creating the statement to send the query
			String query = "SELECT * FROM quote WHERE quote_id='"+_id+"';";
			rs = stmt.executeQuery(query);
			
			if ( rs.next() ) {
				q = new Quote();
				q.setQuote_id(_id);
				q.setMontly_premium(rs.getDouble(2));
				q.setDwelling_coverage(rs.getDouble(3));
				q.setDetached_structures(rs.getDouble(4));
				q.setPersonal_property(rs.getDouble(5));
				q.setAdditional_expense(rs.getDouble(6));
				q.setMedical_expense(rs.getDouble(7));
				q.setDeductible(rs.getDouble(8));
				q.setUser_email(rs.getString(9));
				q.setHomeowner_id(rs.getInt(10));
				q.setProperty_id(rs.getInt(11));
				q.setLocation_id(rs.getInt(12));
				return q;
			}
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return null;
	}
	
	public List<Quote> getAllQuotes(String _email) throws ClassNotFoundException, SQLException, IOException{
		List<Quote> qList = null;
		Quote q = null;
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			stmt = conn.createStatement();//creating the statement to send the query
			String query = "SELECT * FROM quote WHERE user_email='"+_email+"';";
			rs = stmt.executeQuery(query);
			
			qList = new ArrayList<Quote>();
			
			while ( rs.next() ) {
				q = new Quote();
				q.setQuote_id(rs.getInt(1));
				q.setMontly_premium(rs.getDouble(2));
				q.setDwelling_coverage(rs.getDouble(3));
				q.setDetached_structures(rs.getDouble(4));
				q.setPersonal_property(rs.getDouble(5));
				q.setAdditional_expense(rs.getDouble(6));
				q.setMedical_expense(rs.getDouble(7));
				q.setDeductible(rs.getDouble(8));
				q.setUser_email(rs.getString(9));
				q.setHomeowner_id(rs.getInt(10));
				q.setProperty_id(rs.getInt(11));
				q.setLocation_id(rs.getInt(12));
				qList.add(q);
			}
			return qList;
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return null;
	}
}
