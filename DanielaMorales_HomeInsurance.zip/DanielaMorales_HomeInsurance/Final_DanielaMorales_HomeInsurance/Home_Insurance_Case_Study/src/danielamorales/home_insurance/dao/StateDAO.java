package danielamorales.home_insurance.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import danielamorales.home_insurance.model.State;

public class StateDAO {
	
	private Connection conn = null;
	private Statement stmt = null; // query
	private ResultSet rs = null; //return the rows
	
	public State getState(Integer _id) throws ClassNotFoundException, SQLException, IOException{
		State s = null;
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			stmt = conn.createStatement();//creating the statement to send the query
			String query = "SELECT * FROM state WHERE state_id='"+_id+"';";
			rs = stmt.executeQuery(query);
			
			if ( rs.next() ) {
				s = new State();
				s.setState_id(_id);
				s.setCode(rs.getString(2));
				s.setState_name(rs.getString(3));
				return s;
			}
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return null;
	}
	
	public List<State> getAllState() throws ClassNotFoundException, SQLException, IOException{
		State s = null;
		List<State> listState = new ArrayList<State>();
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			stmt = conn.createStatement();//creating the statement to send the query
			String query = "SELECT * FROM state ORDER BY code;";
			rs = stmt.executeQuery(query);
			
			while ( rs.next() ) {
				s = new State();
				s.setState_id(rs.getInt(1));
				s.setCode(rs.getString(2));
				s.setState_name(rs.getString(3));
				listState.add(s);
			}
			
		} catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		return listState;
	}
}
