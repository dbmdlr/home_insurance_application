package danielamorales.home_insurance.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import danielamorales.home_insurance.model.User;

public class UserDAO {
	Connection conn = null;
	Statement stmt = null; // query
	PreparedStatement pStmt = null; // query
	ResultSet rs = null; //return the rows
	
	public int registerUser(User u) throws SQLException, IOException {
		//PreparedStatement pStmt = null; // query
		String query = "INSERT INTO USER(email, password)VALUES(?,?)"; // ? are placeholder that are going to be replaced... *
		int result = 0;
		
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			
			pStmt = conn.prepareStatement(query); //This is the one we used for prepare and replace the placeholder
			pStmt.setString(1, u.getEmail()); //here *
			pStmt.setString(2, u.getPassword()); 
		
			result = pStmt.executeUpdate();
			
		} catch(ClassNotFoundException | SQLException e) {
			 if (((SQLException) e).getErrorCode() == 1062) {
				 System.out.println("That user already exists");
			 }
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		finally {
			if ( rs != null ) {
				rs.close();
			}
			if(pStmt != null) {
				pStmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return result;
	}
	
	public Boolean logIn(User u) throws ClassNotFoundException, SQLException, IOException{
		
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			stmt = conn.createStatement();//creating the statement to send the query
			
			String query = "SELECT * FROM user WHERE email='"+u.getEmail()+"' AND password='"+u.getPassword()+"' AND user.admin="+u.isAdmin()+";";
			rs = stmt.executeQuery(query);
			if ( rs.next() ) {
				return true;
			}
		
		}
		catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		finally {
			if ( rs != null ) {
				rs.close();
			}
			if(stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		
		return false;
	}
	
	public Boolean adminLogIn(User u) throws ClassNotFoundException, SQLException, IOException{
		
		try {
			MySqlConnection mysql = new MySqlConnection();
			conn = mysql.MySQLConnection();
			stmt = conn.createStatement();//creating the statement to send the query
			
			String query = "SELECT * FROM user WHERE email='"+u.getEmail()+"' AND password='"+u.getPassword()+"' AND user.admin=1;";
			rs = stmt.executeQuery(query);
			if ( rs.next() ) {
				return true;
			}
		
		}
		catch(ClassNotFoundException | SQLException e) {
			 System.out.println("SQLException: " + e.getMessage());
			 System.out.println("SQLState: " + ((SQLException) e).getSQLState());
			 System.out.println("VendorError: " + ((SQLException) e).getErrorCode());
		}
		finally {
			if ( rs != null ) {
				rs.close();
			}
			if(stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		
		return false;
	}
	
}
