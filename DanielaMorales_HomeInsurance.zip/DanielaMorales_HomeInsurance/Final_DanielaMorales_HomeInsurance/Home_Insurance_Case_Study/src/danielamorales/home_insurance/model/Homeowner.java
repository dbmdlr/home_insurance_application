package danielamorales.home_insurance.model;

import java.sql.Date;

public class Homeowner{
	private Integer homeowner_id = null;
	private String firstname = null;
	private String lastname = null;
	private Date birthdate = null;
	private Integer retired = null;
	private String ssn = null;
	private String user_email = null;
	
	public Homeowner(Integer homeowner_id, String firstname, String lastname, Date birthdate, Integer retired,
			String ssn, String user_email) {
		super();
		this.homeowner_id = homeowner_id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.birthdate = birthdate;
		this.retired = retired;
		this.ssn = ssn;
		this.user_email = user_email;
	}

	public Homeowner(String firstname, String lastname, Date birthdate, Integer retired,
			String ssn, String user_email) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.birthdate = birthdate;
		this.retired = retired;
		this.ssn = ssn;
		this.user_email = user_email;
	}
	
	public Homeowner() {
		// TODO Auto-generated constructor stub
	}

	public Integer getHomeowner_id() {
		return homeowner_id;
	}

	public void setHomeowner_id(Integer homeowner_id) {
		this.homeowner_id = homeowner_id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Date getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(Date date) {
		this.birthdate = date;
	}

	public Integer getRetired() {
		return retired;
	}

	public void setRetired(Integer retired) {
		this.retired = retired;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	
	
	
	
}
