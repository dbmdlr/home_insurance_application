package danielamorales.home_insurance.model;

public class Location extends State {
	private Integer location_id = null;
	private String address = null;
	private String address2 = null;
	private String city = null;
	private Integer state_id = null;
	private String state = null;
	private Integer zip = null;
	private String residence_type = null;
	private String residence_use = null;
	private String user_email = null;
	
	public Location(Integer location_id, String address, String address2, String city, Integer state_id, Integer zip,
			String residence_type, String residence_use, String user_email) {
		super();
		this.location_id = location_id;
		this.address = address;
		this.address2 = address2;
		this.city = city;
		this.state_id = state_id;
		this.zip = zip;
		this.residence_type = residence_type;
		this.residence_use = residence_use;
		this.user_email = user_email;
	}

	public Location(String address, String address2, String city, Integer state_id, Integer zip,
			String residence_type, String residence_use, String user_email) {
		super();
		this.address = address;
		this.address2 = address2;
		this.city = city;
		this.state_id = state_id;
		this.zip = zip;
		this.residence_type = residence_type;
		this.residence_use = residence_use;
		this.user_email = user_email;
	}
	
	public Location() {
		// TODO Auto-generated constructor stub
	}

	public Integer getLocation_id() {
		return location_id;
	}

	public void setLocation_id(Integer location_id) {
		this.location_id = location_id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Integer getState_id() {
		return state_id;
	}

	public void setState_id(Integer state_id) {
		this.state_id = state_id;
	}

	public Integer getZip() {
		return zip;
	}

	public void setZip(Integer zip) {
		this.zip = zip;
	}

	public String getResidence_type() {
		return residence_type;
	}

	public void setResidence_type(String residence_type) {
		this.residence_type = residence_type;
	}

	public String getResidence_use() {
		return residence_use;
	}

	public void setResidence_use(String residence_use) {
		this.residence_use = residence_use;
	}

	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
}
