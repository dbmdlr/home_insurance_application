package danielamorales.home_insurance.model;

import java.sql.Date;

public class Policy extends Quote {
	private Integer policy_key = null;
	private Date start_date = null;
	private Date expiration_date = null;
	private Integer policy_term = null;
	private Boolean active = null;
	private Integer quote_id = null;
	private String user_email = null;
	private Date renewalDate = null;
	private Boolean renewable = null;
	
	public Policy(Integer quote_id, Double montly_premium, Double dwelling_coverage, Double detached_structures,
			Double personal_property, Double additional_expense, Double medical_expense, Double deductible,
			String user_email, Integer homeowner_id, Integer property_id, Integer location_id) {
		super(quote_id, montly_premium, dwelling_coverage, detached_structures, personal_property, additional_expense,
				medical_expense, deductible, user_email, homeowner_id, property_id, location_id);
		// TODO Auto-generated constructor stub
	}
	
	public Policy(Integer quote_id, Double montly_premium, Double dwelling_coverage, Double detached_structures,
			Double personal_property, Double additional_expense, Double medical_expense, Double deductible,
			String user_email, Integer homeowner_id, Integer property_id, Integer location_id, Integer policy_key,
			Date start_date, Date expiration_date, Integer policy_term, Boolean active, Integer quote_id2,
			String user_email2) {
		super(quote_id, montly_premium, dwelling_coverage, detached_structures, personal_property, additional_expense,
				medical_expense, deductible, user_email, homeowner_id, property_id, location_id);
		this.policy_key = policy_key;
		this.start_date = start_date;
		this.expiration_date = expiration_date;
		this.policy_term = policy_term;
		this.active = active;
		quote_id = quote_id2;
		user_email = user_email2;
	}



	public Policy() {
		// TODO Auto-generated constructor stub
	}


	public Integer getPolicy_key() {
		return policy_key;
	}

	public void setPolicy_key(Integer policy_key) {
		this.policy_key = policy_key;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getExpiration_date() {
		return expiration_date;
	}

	public void setExpiration_date(Date expiration_date) {
		this.expiration_date = expiration_date;
	}

	public Integer getPolicy_term() {
		return policy_term;
	}

	public void setPolicy_term(Integer policy_term) {
		this.policy_term = policy_term;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Integer getQuote_id() {
		return quote_id;
	}

	public void setQuote_id(Integer quote_id) {
		this.quote_id = quote_id;
	}

	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}

	public Date getRenewalDate() {
		return renewalDate;
	}

	public void setRenewalDate(Date renewalDate) {
		this.renewalDate = renewalDate;
	}

	public Boolean getRenewable() {
		return renewable;
	}

	public void setRenewable(Boolean renewable) {
		this.renewable = renewable;
	}
	
	
}	
