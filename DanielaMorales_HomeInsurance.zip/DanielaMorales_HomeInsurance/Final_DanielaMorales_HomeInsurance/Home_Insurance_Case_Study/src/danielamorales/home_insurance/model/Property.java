package danielamorales.home_insurance.model;

public class Property {
	private Integer property_id = null;
	private Integer property_year = null;
	private Double property_square = null;
	private String roof_material = null;
	private String garage_type = null;
	private String baths_number = null;
	private String half_baths_number = null;
	private Integer swimming_pool = null;
	private String dwelling_style = null;
	private String user_email = null;
	private Integer location_id = null;
	private Double property_value = null;
	
	public Property(Integer property_id, Integer property_year, Double property_square, String roof_material,
			String garage_type, String baths_number, String half_baths_number, Integer swimming_pool,
			String dwelling_style, String user_email, Integer location_id) {
		super();
		this.property_id = property_id;
		this.property_year = property_year;
		this.property_square = property_square;
		this.roof_material = roof_material;
		this.garage_type = garage_type;
		this.baths_number = baths_number;
		this.half_baths_number = half_baths_number;
		this.swimming_pool = swimming_pool;
		this.dwelling_style = dwelling_style;
		this.user_email = user_email;
		this.location_id = location_id;
	}
	
	public Property( Integer property_year, Double property_square, String roof_material,
			String garage_type, String baths_number, String half_baths_number, Integer swimming_pool,
			String dwelling_style, String user_email, Integer location_id, Double property_value) {
		super();
		this.property_year = property_year;
		this.property_square = property_square;
		this.roof_material = roof_material;
		this.garage_type = garage_type;
		this.baths_number = baths_number;
		this.half_baths_number = half_baths_number;
		this.swimming_pool = swimming_pool;
		this.dwelling_style = dwelling_style;
		this.user_email = user_email;
		this.property_value = property_value;
		this.location_id = location_id;
	}

	public Property() {
		// TODO Auto-generated constructor stub
	}

	public Integer getProperty_id() {
		return property_id;
	}

	public void setProperty_id(Integer property_id) {
		this.property_id = property_id;
	}

	public Integer getProperty_year() {
		return property_year;
	}

	public void setProperty_year(Integer property_year) {
		this.property_year = property_year;
	}

	public Double getProperty_square() {
		return property_square;
	}

	public void setProperty_square(Double property_square) {
		this.property_square = property_square;
	}

	public String getRoof_material() {
		return roof_material;
	}

	public void setRoof_material(String roof_material) {
		this.roof_material = roof_material;
	}

	public String getGarage_type() {
		return garage_type;
	}

	public void setGarage_type(String garage_type) {
		this.garage_type = garage_type;
	}

	public String getBaths_number() {
		return baths_number;
	}

	public void setBaths_number(String baths_number) {
		this.baths_number = baths_number;
	}

	public String getHalf_baths_number() {
		return half_baths_number;
	}

	public void setHalf_baths_number(String half_baths_number) {
		this.half_baths_number = half_baths_number;
	}

	public Integer getSwimming_pool() {
		return swimming_pool;
	}

	public void setSwimming_pool(Integer swimming_pool) {
		this.swimming_pool = swimming_pool;
	}

	public String getDwelling_style() {
		return dwelling_style;
	}

	public void setDwelling_style(String dwelling_style) {
		this.dwelling_style = dwelling_style;
	}

	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}

	public Integer getLocation_id() {
		return location_id;
	}

	public void setLocation_id(Integer location_id) {
		this.location_id = location_id;
	}

	public Double getProperty_value() {
		return property_value;
	}

	public void setProperty_value(Double property_value) {
		this.property_value = property_value;
	}
	
	
	
}
