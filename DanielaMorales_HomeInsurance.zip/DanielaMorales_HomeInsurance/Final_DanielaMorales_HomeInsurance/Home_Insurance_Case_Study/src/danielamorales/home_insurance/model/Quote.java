package danielamorales.home_insurance.model;

public class Quote {
	private Integer quote_id = null;
	private Double montly_premium = null;
	private Double dwelling_coverage = null;
	private Double detached_structures = null;
	private Double personal_property = null;
	private Double additional_expense = null;
	private Double medical_expense = null;
	private Double deductible = null;
	private String user_email = null;
	private Integer homeowner_id = null;
	private Integer property_id = null;
	private Integer location_id = null;
	
	public Quote(Integer quote_id, Double montly_premium, Double dwelling_coverage, Double detached_structures,
			Double personal_property, Double additional_expense, Double medical_expense, Double deductible,
			String user_email, Integer homeowner_id, Integer property_id, Integer location_id) {
		super();
		this.quote_id = quote_id;
		this.montly_premium = montly_premium;
		this.dwelling_coverage = dwelling_coverage;
		this.detached_structures = detached_structures;
		this.personal_property = personal_property;
		this.additional_expense = additional_expense;
		this.medical_expense = medical_expense;
		this.deductible = deductible;
		this.user_email = user_email;
		this.homeowner_id = homeowner_id;
		this.property_id = property_id;
		this.location_id = location_id;
	}
	
	public Quote(Double montly_premium, Double dwelling_coverage, Double detached_structures,
			Double personal_property, Double additional_expense, Double medical_expense, Double deductible,
			String user_email, Integer homeowner_id, Integer property_id, Integer location_id) {
		super();
		this.montly_premium = montly_premium;
		this.dwelling_coverage = dwelling_coverage;
		this.detached_structures = detached_structures;
		this.personal_property = personal_property;
		this.additional_expense = additional_expense;
		this.medical_expense = medical_expense;
		this.deductible = deductible;
		this.user_email = user_email;
		this.homeowner_id = homeowner_id;
		this.property_id = property_id;
		this.location_id = location_id;
	}

	public Quote() {
		// TODO Auto-generated constructor stub
	}

	public Integer getQuote_id() {
		return quote_id;
	}

	public void setQuote_id(Integer quote_id) {
		this.quote_id = quote_id;
	}

	public Double getMontly_premium() {
		return montly_premium;
	}

	public void setMontly_premium(Double montly_premium) {
		this.montly_premium = montly_premium;
	}

	public Double getDwelling_coverage() {
		return dwelling_coverage;
	}

	public void setDwelling_coverage(Double dwelling_coverage) {
		this.dwelling_coverage = dwelling_coverage;
	}

	public Double getDetached_structures() {
		return detached_structures;
	}

	public void setDetached_structures(Double detached_structures) {
		this.detached_structures = detached_structures;
	}

	public Double getPersonal_property() {
		return personal_property;
	}

	public void setPersonal_property(Double personal_property) {
		this.personal_property = personal_property;
	}

	public Double getAdditional_expense() {
		return additional_expense;
	}

	public void setAdditional_expense(Double additional_expense) {
		this.additional_expense = additional_expense;
	}

	public Double getMedical_expense() {
		return medical_expense;
	}

	public void setMedical_expense(Double medical_expense) {
		this.medical_expense = medical_expense;
	}

	public Double getDeductible() {
		return deductible;
	}

	public void setDeductible(Double deductible) {
		this.deductible = deductible;
	}

	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}

	public Integer getHomeowner_id() {
		return homeowner_id;
	}

	public void setHomeowner_id(Integer homeowner_id) {
		this.homeowner_id = homeowner_id;
	}

	public Integer getProperty_id() {
		return property_id;
	}

	public void setProperty_id(Integer property_id) {
		this.property_id = property_id;
	}

	public Integer getLocation_id() {
		return location_id;
	}

	public void setLocation_id(Integer location_id) {
		this.location_id = location_id;
	}
	
	
}
