package danielamorales.home_insurance.model;

public class User {

	private String email;
	private String password;
	private Integer admin;
	
	public User() {}
	
	public User( String email, String password) {
		super();
		this.email = email;
		this.password = password;
		this.admin = 0;
	}
	
	public User( String email, String password, Integer admin) {
		super();
		this.email = email;
		this.password = password;
		this.admin = admin;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer isAdmin() {
		return admin;
	}

	public void setAdmin(Integer admin) {
		this.admin = admin;
	}

}
