package danielamorales.home_insurance.systemInterface;

import java.io.IOException;
import java.sql.SQLException;

import danielamorales.home_insurance.model.Homeowner;

public interface HomeownerDAOI {

	public Homeowner getHomeowner(Integer _id) throws ClassNotFoundException, SQLException, IOException;
	
	public Integer postHomeowner(Homeowner h) throws ClassNotFoundException, SQLException, IOException;
	
}
