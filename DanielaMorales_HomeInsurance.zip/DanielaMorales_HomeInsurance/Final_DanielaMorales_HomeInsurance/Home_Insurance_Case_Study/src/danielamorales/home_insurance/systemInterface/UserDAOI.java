package danielamorales.home_insurance.systemInterface;

import java.io.IOException;
import java.sql.SQLException;

import danielamorales.home_insurance.model.User;

public interface UserDAOI {
	public Boolean logIn(User u) throws ClassNotFoundException, SQLException, IOException;
	
	public int registerUser(User u) throws SQLException, IOException;
}
