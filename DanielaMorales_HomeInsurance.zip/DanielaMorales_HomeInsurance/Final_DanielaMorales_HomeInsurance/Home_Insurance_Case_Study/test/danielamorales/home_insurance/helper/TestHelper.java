package danielamorales.home_insurance.helper;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import danielamorales.home_insurance.dao.MySqlConnection;

public class TestHelper {
	  public static Boolean deleteRecordHelper(String query) throws ClassNotFoundException, IOException, SQLException {
	    	Connection conn = null;
	    	PreparedStatement stmt = null;
	        int result = 0;
	        MySqlConnection mysql = new MySqlConnection();
	        try
	        {
	            conn = mysql.MySQLConnection();
	            stmt = conn.prepareStatement(query);
	            //stmt.executeUpdate();
	            result = stmt.executeUpdate(query);
	            //System.out.println(result);
	        }
	        catch (ClassNotFoundException e)
	        {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        catch (IOException e)
	        {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        catch (SQLException e)
	        {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }finally {
	        	if (result > 0) {
	            	return true;
	            }
	        }
			return false;
	    }
	  
		  public static java.sql.Date formatDate(String d) throws ParseException{
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		        Date parsed = format.parse(d);
		        java.sql.Date sql = new java.sql.Date(parsed.getTime());
				return sql;
		  }
}
