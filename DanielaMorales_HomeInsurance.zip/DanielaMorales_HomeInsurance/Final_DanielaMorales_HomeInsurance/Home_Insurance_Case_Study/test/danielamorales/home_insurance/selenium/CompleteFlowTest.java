package danielamorales.home_insurance.selenium;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.core.IsNot.not;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import danielamorales.home_insurance.helper.TestHelper;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CompleteFlowTest {
	static WebDriver driver;
	static UserRegistrationTest registration;
	static String quoteID;
	static Actions actions;
	@BeforeClass
	public static void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Student\\Desktop\\DanielaDB\\caseStudy\\chromedriver.exe");
		 driver = new ChromeDriver();
		 actions = new Actions(driver);
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 //registration = new UserRegistrationTest();
		 driver.get("http://localhost:8080/Home_Insurance_Case_Study/login");
	}
	
	private boolean existsElement(String id) {
	    try {
	        driver.findElement(By.cssSelector(id));
	    } catch (NoSuchElementException e) {
	        return false;
	    }
	    return true;
	}
	
	@Test
	public void a_LogInFailTest() throws InterruptedException {
		WebElement emailInput = driver.findElement(By.name("email"));
		emailInput.sendKeys("user@gmail.com");
		Thread.sleep(2000);
		WebElement passwordInput = driver.findElement(By.name("password"));
		passwordInput.sendKeys("userpassword123");
		Thread.sleep(2000);
		WebElement submitInput = driver.findElement(By.name("submit"));
		submitInput.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/login"));
		Thread.sleep(1000);
	}	
	
	@Test
	public void b_registrationLinkTest() throws InterruptedException {
		Thread.sleep(1000);
		WebElement linkRegistration = driver.findElement(By.cssSelector("a[class='forgot col-md-4']"));
		linkRegistration.click();
		Thread.sleep(2000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/registration"));
		
		//registration.registerUserFailTest();
		//registration.registerUserSuccessTest();
		
		//This works and helps to keep the flow and each test in separate
		//classes but the call is executed as a java method and not 
		//as a Junit test and doesn't display the test reports
	}
	
	@Test
	public void c_registerUserFailTest() throws InterruptedException {
		WebElement emailInput = driver.findElement(By.name("email-registration"));
		emailInput.sendKeys("user@gmail.com");
		Thread.sleep(2000);
		WebElement passwordInput = driver.findElement(By.name("password-registration"));
		passwordInput.sendKeys("userpassword321");
		Thread.sleep(2000);
		WebElement rpasswordInput = driver.findElement(By.name("rpassword-registration"));
		rpasswordInput.sendKeys("userpassword123");
		WebElement submitInput = driver.findElement(By.cssSelector("button[type=submit]"));
		submitInput.click();
		Thread.sleep(1000);
		
		WebElement errorDisplayed = driver.findElement(By.cssSelector("div[id='logInError']"));
		assertThat(errorDisplayed.isDisplayed(), is(true));
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/registration"));			
	}
	
	@Test
	public void d_registerUserSuccessTest() throws InterruptedException {
		WebElement emailInput = driver.findElement(By.name("email-registration"));
		emailInput.sendKeys("user@gmail.com");
		Thread.sleep(2000);
		WebElement passwordInput = driver.findElement(By.name("password-registration"));
		passwordInput.sendKeys("userpassword123");
		Thread.sleep(2000);
		WebElement rpasswordInput = driver.findElement(By.name("rpassword-registration"));
		rpasswordInput.sendKeys("userpassword123");
		WebElement submitInput = driver.findElement(By.cssSelector("button[type=submit]"));
		submitInput.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/welcome"));
		
		WebElement linkToLogin = driver.findElement(By.cssSelector("a[name='goBackLink']"));
		linkToLogin.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/login"));
	}
	
	@Test
	public void e_LogInSuccessTest() throws InterruptedException {
		WebElement emailInput = driver.findElement(By.name("email"));
		emailInput.sendKeys("user@gmail.com");
		Thread.sleep(2000);
		WebElement passwordInput = driver.findElement(By.name("password"));
		passwordInput.sendKeys("userpassword123");
		Thread.sleep(2000);
		WebElement submitInput = driver.findElement(By.name("submit"));
		Thread.sleep(1000);
		submitInput.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/home"));
	}
	
	@Test
	public void f_GetQuoteLocationFailTest() throws InterruptedException {
		//Testing if button Get Quote in home page works
		WebElement liGenerateQuote = driver.findElement(By.cssSelector("a[href='./createQuote']"));
		liGenerateQuote.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/createQuote"));
		
		WebElement addressInput = driver.findElement(By.cssSelector("input[id='addressInput']"));
		assertThat(addressInput.isDisplayed(), is(true));
		//Filling the form and making sure the right data is displayed
		Select inputResidenceType = new Select(driver.findElement(By.id("residenceTypeSelect")));
		assertThat(inputResidenceType.getOptions().size(), not(0));
		
		inputResidenceType.selectByValue("Duplex");
		addressInput.sendKeys("4259 Wallaby Way");
		
		WebElement cityInput = driver.findElement(By.cssSelector("input[id='cityInput']"));
		cityInput.sendKeys("Miami");
		Thread.sleep(1000);
		Select inputState = new Select(driver.findElement(By.id("stateSelect")));
		assertThat(inputState.getOptions().size(), not(0));
		inputState.selectByVisibleText("Florida");
		
		WebElement zipInput = driver.findElement(By.cssSelector("input[id='zipInput']"));
		zipInput.sendKeys("752ssm6");
		Select inputResidenceUse = new Select(driver.findElement(By.id("residenceUseInput")));
		assertThat(inputResidenceUse.getOptions().size(), not(0));
		inputResidenceUse.selectByVisibleText("Secondary");
		Thread.sleep(1000);
		
		WebElement btnLocationSubmit = driver.findElement(By.cssSelector("button[type='submit']"));
		btnLocationSubmit.click();
		Thread.sleep(1000);
		WebElement errorDisplayed = driver.findElement(By.cssSelector("div[class='alert alert-danger col-md-8']"));
		assertThat(errorDisplayed.isDisplayed(), is(true));
		Thread.sleep(1000);
	}
	
	@Test
	public void g_GetQuoteLocationSuccessTest() throws InterruptedException {
		WebElement addressInput = driver.findElement(By.cssSelector("input[id='addressInput']"));
		assertThat(addressInput.isDisplayed(), is(true));
		//Filling the form and making sure the right data is displayed
		Select inputResidenceType = new Select(driver.findElement(By.id("residenceTypeSelect")));
		assertThat(inputResidenceType.getOptions().size(), not(0));
		
		inputResidenceType.selectByValue("Duplex");
		addressInput.sendKeys("4259 Wallaby Way");
		
		WebElement cityInput = driver.findElement(By.cssSelector("input[id='cityInput']"));
		cityInput.sendKeys("Miami");
		Thread.sleep(1000);
		Select inputState = new Select(driver.findElement(By.id("stateSelect")));
		assertThat(inputState.getOptions().size(), not(0));
		inputState.selectByVisibleText("Florida");
		
		WebElement zipInput = driver.findElement(By.cssSelector("input[id='zipInput']"));
		zipInput.sendKeys("75256");
		Select inputResidenceUse = new Select(driver.findElement(By.id("residenceUseInput")));
		assertThat(inputResidenceUse.getOptions().size(), not(0));
		inputResidenceUse.selectByVisibleText("Secondary");
		Thread.sleep(1000);
		
		WebElement btnLocationSubmit = driver.findElement(By.cssSelector("button[type='submit']"));
		btnLocationSubmit.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/homeowner"));
	}
	
	@Test
	public void h_GetQuoteHomeownerSuccessTest() throws InterruptedException {
		WebElement firstnameInput = driver.findElement(By.cssSelector("input[id='firstNameInput']"));
		WebElement lastnameInput = driver.findElement(By.cssSelector("input[id='LastNameInput']"));
		WebElement birthdateInput = driver.findElement(By.cssSelector("input[id='birthdateInput']"));
		WebElement ssnInput = driver.findElement(By.cssSelector("input[id='ssnInput']"));
		WebElement btnHomeownerSubmit = driver.findElement(By.cssSelector("button[id='inputHomeowner']"));
		
		assertThat(firstnameInput.isDisplayed(), is(true));
		//Filling the form 
		firstnameInput.sendKeys("Bruce");
		lastnameInput.sendKeys("Wayne");
		Thread.sleep(1000);
		birthdateInput.sendKeys("1993-12-16");
		ssnInput.sendKeys("222335555");
		Thread.sleep(1000);
		btnHomeownerSubmit.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/property"));
	}
	
	@Test
	public void i_GetQuotePropertyFailTest() throws InterruptedException {
		WebElement btnPropertySubmit = driver.findElement(By.cssSelector("button[id='propertySubmit']"));
		WebElement marketValueInput = driver.findElement(By.cssSelector("input[id='marketValueInput']"));
		WebElement yearBuiltInput = driver.findElement(By.cssSelector("input[id='yearBuiltInput']"));
		WebElement squareFootageInput = driver.findElement(By.cssSelector("input[id='squareFootageInput']"));
		Select dwellingSelect = new Select(driver.findElement(By.id("dwellingSelect")));
		Select roofSelect = new Select(driver.findElement(By.id("roofSelect")));
		Select garageSelect = new Select(driver.findElement(By.id("garageSelect")));
		Select bathSelect = new Select(driver.findElement(By.id("bathSelect")));
		Select halfBathSelect = new Select(driver.findElement(By.id("halfBathSelect")));
		
		assertThat(dwellingSelect.getOptions().size(), not(0));
		assertThat(roofSelect.getOptions().size(), not(0));
		assertThat(garageSelect.getOptions().size(), not(0));
		assertThat(bathSelect.getOptions().size(), not(0));
		assertThat(halfBathSelect.getOptions().size(), not(0));
		assertThat(marketValueInput.isDisplayed(), is(true));
		//Filling the form 
		marketValueInput.sendKeys("230233.55");
		yearBuiltInput.sendKeys("20");
		squareFootageInput.sendKeys("525.55");
		dwellingSelect.selectByVisibleText("1.5 Story");
		roofSelect.selectByVisibleText("Wood");
		garageSelect.selectByVisibleText("Detached");
		bathSelect.selectByVisibleText("2");
		halfBathSelect.selectByVisibleText("More");
		Thread.sleep(1000);
		btnPropertySubmit.click();
		Thread.sleep(1000);
		WebElement errorDisplayed = driver.findElement(By.cssSelector("div[id='errorProperty']"));
		assertThat(errorDisplayed.isDisplayed(), is(true));
	}
	
	@Test
	public void j_GetQuotePropertySuccessTest() throws InterruptedException {
		WebElement btnPropertySubmit = driver.findElement(By.cssSelector("button[id='propertySubmit']"));
		WebElement marketValueInput = driver.findElement(By.cssSelector("input[id='marketValueInput']"));
		WebElement yearBuiltInput = driver.findElement(By.cssSelector("input[id='yearBuiltInput']"));
		WebElement squareFootageInput = driver.findElement(By.cssSelector("input[id='squareFootageInput']"));
		Select dwellingSelect = new Select(driver.findElement(By.id("dwellingSelect")));
		Select roofSelect = new Select(driver.findElement(By.id("roofSelect")));
		Select garageSelect = new Select(driver.findElement(By.id("garageSelect")));
		Select bathSelect = new Select(driver.findElement(By.id("bathSelect")));
		Select halfBathSelect = new Select(driver.findElement(By.id("halfBathSelect")));
		
		assertThat(dwellingSelect.getOptions().size(), not(0));
		assertThat(roofSelect.getOptions().size(), not(0));
		assertThat(garageSelect.getOptions().size(), not(0));
		assertThat(bathSelect.getOptions().size(), not(0));
		assertThat(halfBathSelect.getOptions().size(), not(0));
		assertThat(marketValueInput.isDisplayed(), is(true));
		//Filling the form 
		marketValueInput.sendKeys("230233.55");
		yearBuiltInput.sendKeys("2002");
		squareFootageInput.sendKeys("525.55");
		dwellingSelect.selectByVisibleText("1.5 Story");
		roofSelect.selectByVisibleText("Wood");
		garageSelect.selectByVisibleText("Detached");
		bathSelect.selectByVisibleText("2");
		halfBathSelect.selectByVisibleText("More");
		Thread.sleep(1000);
		btnPropertySubmit.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/generateQuote"));
	}
	
	@Test
	public void k_getQuoteNavBarTest() throws InterruptedException {
		WebElement liGetQuote = driver.findElement(By.cssSelector("a[href='./getQuote']"));
		liGetQuote.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/getQuote"));
	}
	
	@Test
	public void l_selectQuoteTest() throws InterruptedException {
		WebElement table = driver.findElement(By.xpath("//table[@id='quotesTable']"));
		List<WebElement> row = table.findElements(By.tagName("tr"));
		assertThat(row.size(), is(notNullValue()));
		Thread.sleep(1000);
		
		quoteID =row.get(1).findElement(By.className("quoteID")).getText();
		row.get(1).findElement(By.cssSelector("input[type=submit]")).click();

		WebElement quoteIDHiddenInput = driver.findElement(By.name("quoteIDToBuy"));
		assertThat(quoteID, is(equalTo(quoteIDHiddenInput.getAttribute("value"))));
		Thread.sleep(1000);
	}
	
	@Test 
	public void m_buyingPolicyLinkTest() throws InterruptedException {
		WebElement buyPolicyBtn = driver.findElement(By.cssSelector("button[type=submit]"));
		buyPolicyBtn.click();
		Thread.sleep(1000);
		
		WebElement text = driver.findElement(By.cssSelector("a[target='_blank']"));
		assertThat(text.isDisplayed(), is(true));
	}
	
	@Test 
	public void n_buyingPolicyFailTest() throws InterruptedException {
		driver.findElement(By.cssSelector("input[name='startDate']")).sendKeys("2018-12-12");
		WebElement checkbox = driver.findElement(By.cssSelector("input[type='checkbox']"));
		actions.moveToElement(checkbox).click().perform();
		Thread.sleep(1000);
		
		WebElement buyPolicyBtn = driver.findElement(By.cssSelector("button[id='buyPolicyBtn']"));
		buyPolicyBtn.click();
		Thread.sleep(1000);
		
		WebElement dangerAlert = driver.findElement(By.id("alertStartDateError"));
		assertThat(dangerAlert.isDisplayed(), is(true));
	}
	
	@Test 
	public void o_buyingPolicySuccessTest() throws InterruptedException {
		driver.findElement(By.cssSelector("input[name='startDate']")).sendKeys("2018-10-05");
		WebElement checkbox = driver.findElement(By.cssSelector("input[type='checkbox']"));
		actions.moveToElement(checkbox).click().perform();
		Thread.sleep(1000);
		
		WebElement buyPolicyBtn = driver.findElement(By.cssSelector("button[id='buyPolicyBtn']"));
		buyPolicyBtn.click();
		Thread.sleep(1000);
		
		assertThat( driver.findElement(By.id("startDateDisplay")).getAttribute("value"), is(equalTo("2018-10-05")));
	}
	
	@Test
	public void p_RetrievePoliciesLinkTest() throws InterruptedException {
		WebElement liPolicies = driver.findElement(By.cssSelector("a[href='./getPolicies']"));
		liPolicies.click();
		Thread.sleep(1000);
		assertThat(driver.findElement(By.cssSelector("i[class='fas fa-th-list']")).isDisplayed(), is(true));
		Thread.sleep(1000);
	}
	
	@Test
	public void q_RetrievePoliciesTest() throws InterruptedException {
		if ( existsElement("table[class='table table-bordered']") ) {
			WebElement table = driver.findElement(By.cssSelector("table[class='table table-bordered']"));
			List<WebElement> row = table.findElements(By.tagName("tr"));
			assertThat(row.size(), is(not(0)));
		}else {
			assertThat(driver.findElement(By.cssSelector("div[class='alert alert-info']")).isDisplayed(), is(true));
		}
		Thread.sleep(1000);
	}
	
	@Test
	public void r_LogOutTest() throws InterruptedException {
		WebElement logOutLi = driver.findElement(By.cssSelector("a[href='./logout']"));
		Thread.sleep(1000);
		logOutLi.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/logout"));
	}
	
	@AfterClass
	public static void cleanUp() throws ClassNotFoundException, IOException, SQLException {
		// Conclude test
		String query = "DELETE FROM USER WHERE email='user@gmail.com';";
		TestHelper.deleteRecordHelper(query);
		
		query = "DELETE FROM QUOTE WHERE quote_id="+quoteID+";";
		TestHelper.deleteRecordHelper(query);
		
		query = "DELETE FROM POLICY WHERE quote_id="+quoteID+";";
		TestHelper.deleteRecordHelper(query);
		
	    driver.quit();
	}

}
