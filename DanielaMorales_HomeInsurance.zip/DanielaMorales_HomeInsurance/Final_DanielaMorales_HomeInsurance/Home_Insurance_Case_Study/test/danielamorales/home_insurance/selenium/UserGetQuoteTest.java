package danielamorales.home_insurance.selenium;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class UserGetQuoteTest {

	static WebDriver driver;
	@BeforeClass
	public static void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Student\\Desktop\\DanielaDB\\caseStudy\\chromedriver.exe");
		 driver = new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 driver.get("http://localhost:8080/Home_Insurance_Case_Study/login");
	}

	@Test
	public void a_LogInSuccessTest() throws InterruptedException {
		WebElement emailInput = driver.findElement(By.name("email"));
		emailInput.sendKeys("dani@gmail.com");
		Thread.sleep(2000);
		WebElement passwordInput = driver.findElement(By.name("password"));
		passwordInput.sendKeys("daniela12");
		Thread.sleep(2000);
		WebElement submitInput = driver.findElement(By.name("submit"));
		Thread.sleep(1000);
		submitInput.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/home"));
	}
	
	@Test
	public void f_GetQuoteLocationFailTest() throws InterruptedException {
		//Testing if button Get Quote in home page works
		WebElement liGenerateQuote = driver.findElement(By.cssSelector("a[href='./createQuote']"));
		liGenerateQuote.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/createQuote"));
		
		WebElement addressInput = driver.findElement(By.cssSelector("input[id='addressInput']"));
		assertThat(addressInput.isDisplayed(), is(true));
		//Filling the form and making sure the right data is displayed
		Select inputResidenceType = new Select(driver.findElement(By.id("residenceTypeSelect")));
		assertThat(inputResidenceType.getOptions().size(), not(0));
		
		inputResidenceType.selectByValue("Duplex");
		addressInput.sendKeys("4259 Wallaby Way");
		
		WebElement cityInput = driver.findElement(By.cssSelector("input[id='cityInput']"));
		cityInput.sendKeys("Miami");
		Thread.sleep(1000);
		Select inputState = new Select(driver.findElement(By.id("stateSelect")));
		assertThat(inputState.getOptions().size(), not(0));
		inputState.selectByVisibleText("Florida");
		
		WebElement zipInput = driver.findElement(By.cssSelector("input[id='zipInput']"));
		zipInput.sendKeys("752ssm6");
		Select inputResidenceUse = new Select(driver.findElement(By.id("residenceUseInput")));
		assertThat(inputResidenceUse.getOptions().size(), not(0));
		inputResidenceUse.selectByVisibleText("Secondary");
		Thread.sleep(1000);
		
		WebElement btnLocationSubmit = driver.findElement(By.cssSelector("button[type='submit']"));
		btnLocationSubmit.click();
		Thread.sleep(1000);
		WebElement errorDisplayed = driver.findElement(By.cssSelector("div[class='alert alert-danger col-md-8']"));
		assertThat(errorDisplayed.isDisplayed(), is(true));
		Thread.sleep(1000);
	}
	
	@Test
	public void g_GetQuoteLocationSuccessTest() throws InterruptedException {
		WebElement addressInput = driver.findElement(By.cssSelector("input[id='addressInput']"));
		assertThat(addressInput.isDisplayed(), is(true));
		//Filling the form and making sure the right data is displayed
		Select inputResidenceType = new Select(driver.findElement(By.id("residenceTypeSelect")));
		assertThat(inputResidenceType.getOptions().size(), not(0));
		
		inputResidenceType.selectByValue("Duplex");
		addressInput.sendKeys("4259 Wallaby Way");
		
		WebElement cityInput = driver.findElement(By.cssSelector("input[id='cityInput']"));
		cityInput.sendKeys("Miami");
		Thread.sleep(1000);
		Select inputState = new Select(driver.findElement(By.id("stateSelect")));
		assertThat(inputState.getOptions().size(), not(0));
		inputState.selectByVisibleText("Florida");
		
		WebElement zipInput = driver.findElement(By.cssSelector("input[id='zipInput']"));
		zipInput.sendKeys("75256");
		Select inputResidenceUse = new Select(driver.findElement(By.id("residenceUseInput")));
		assertThat(inputResidenceUse.getOptions().size(), not(0));
		inputResidenceUse.selectByVisibleText("Secondary");
		Thread.sleep(1000);
		
		WebElement btnLocationSubmit = driver.findElement(By.cssSelector("button[type='submit']"));
		btnLocationSubmit.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/homeowner"));
	}
	
	@Test
	public void h_GetQuoteHomeownerSuccessTest() throws InterruptedException {
		WebElement firstnameInput = driver.findElement(By.cssSelector("input[id='firstNameInput']"));
		WebElement lastnameInput = driver.findElement(By.cssSelector("input[id='LastNameInput']"));
		WebElement birthdateInput = driver.findElement(By.cssSelector("input[id='birthdateInput']"));
		WebElement ssnInput = driver.findElement(By.cssSelector("input[id='ssnInput']"));
		WebElement btnHomeownerSubmit = driver.findElement(By.cssSelector("button[id='inputHomeowner']"));
		
		assertThat(firstnameInput.isDisplayed(), is(true));
		//Filling the form 
		firstnameInput.sendKeys("Bruce");
		lastnameInput.sendKeys("Wayne");
		Thread.sleep(1000);
		birthdateInput.sendKeys("1993-12-16");
		ssnInput.sendKeys("222335555");
		Thread.sleep(1000);
		btnHomeownerSubmit.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/property"));
	}
	
	
	@Test
	public void i_GetQuotePropertyFailTest() throws InterruptedException {
		WebElement btnPropertySubmit = driver.findElement(By.cssSelector("button[id='propertySubmit']"));
		WebElement marketValueInput = driver.findElement(By.cssSelector("input[id='marketValueInput']"));
		WebElement yearBuiltInput = driver.findElement(By.cssSelector("input[id='yearBuiltInput']"));
		WebElement squareFootageInput = driver.findElement(By.cssSelector("input[id='squareFootageInput']"));
		Select dwellingSelect = new Select(driver.findElement(By.id("dwellingSelect")));
		Select roofSelect = new Select(driver.findElement(By.id("roofSelect")));
		Select garageSelect = new Select(driver.findElement(By.id("garageSelect")));
		Select bathSelect = new Select(driver.findElement(By.id("bathSelect")));
		Select halfBathSelect = new Select(driver.findElement(By.id("halfBathSelect")));
		
		assertThat(dwellingSelect.getOptions().size(), not(0));
		assertThat(roofSelect.getOptions().size(), not(0));
		assertThat(garageSelect.getOptions().size(), not(0));
		assertThat(bathSelect.getOptions().size(), not(0));
		assertThat(halfBathSelect.getOptions().size(), not(0));
		assertThat(marketValueInput.isDisplayed(), is(true));
		//Filling the form 
		marketValueInput.sendKeys("230233.55");
		yearBuiltInput.sendKeys("20");
		squareFootageInput.sendKeys("525.55");
		dwellingSelect.selectByVisibleText("1.5 Story");
		roofSelect.selectByVisibleText("Wood");
		garageSelect.selectByVisibleText("Detached");
		bathSelect.selectByVisibleText("2");
		halfBathSelect.selectByVisibleText("More");
		Thread.sleep(1000);
		btnPropertySubmit.click();
		Thread.sleep(1000);
		WebElement errorDisplayed = driver.findElement(By.cssSelector("div[id='errorProperty']"));
		assertThat(errorDisplayed.isDisplayed(), is(true));
	}
	
	@Test
	public void j_GetQuotePropertySuccessTest() throws InterruptedException {
		WebElement btnPropertySubmit = driver.findElement(By.cssSelector("button[id='propertySubmit']"));
		WebElement marketValueInput = driver.findElement(By.cssSelector("input[id='marketValueInput']"));
		WebElement yearBuiltInput = driver.findElement(By.cssSelector("input[id='yearBuiltInput']"));
		WebElement squareFootageInput = driver.findElement(By.cssSelector("input[id='squareFootageInput']"));
		Select dwellingSelect = new Select(driver.findElement(By.id("dwellingSelect")));
		Select roofSelect = new Select(driver.findElement(By.id("roofSelect")));
		Select garageSelect = new Select(driver.findElement(By.id("garageSelect")));
		Select bathSelect = new Select(driver.findElement(By.id("bathSelect")));
		Select halfBathSelect = new Select(driver.findElement(By.id("halfBathSelect")));
		
		assertThat(dwellingSelect.getOptions().size(), not(0));
		assertThat(roofSelect.getOptions().size(), not(0));
		assertThat(garageSelect.getOptions().size(), not(0));
		assertThat(bathSelect.getOptions().size(), not(0));
		assertThat(halfBathSelect.getOptions().size(), not(0));
		assertThat(marketValueInput.isDisplayed(), is(true));
		//Filling the form 
		marketValueInput.sendKeys("230233.55");
		yearBuiltInput.sendKeys("2002");
		squareFootageInput.sendKeys("525.55");
		dwellingSelect.selectByVisibleText("1.5 Story");
		roofSelect.selectByVisibleText("Wood");
		garageSelect.selectByVisibleText("Detached");
		bathSelect.selectByVisibleText("2");
		halfBathSelect.selectByVisibleText("More");
		Thread.sleep(1000);
		btnPropertySubmit.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/generateQuote"));
	}
	
	@AfterClass
	public static void cleanUp() throws ClassNotFoundException, IOException, SQLException {
		// Conclude test
		//String query = "DELETE FROM QUOTE WHERE user_email='user@gmail.com';";
		//TestHelper.deleteRecordHelper(query);
	    driver.quit();
	}

}
