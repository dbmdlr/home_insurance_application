package danielamorales.home_insurance.selenium;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class UserLogInTest {

	static WebDriver driver;
	@BeforeClass
	public static void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Student\\Desktop\\DanielaDB\\caseStudy\\chromedriver.exe");
		 driver = new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 driver.get("http://localhost:8080/Home_Insurance_Case_Study/login");
	}
  
	@Test
	public void a_LogInFailTest() throws InterruptedException {
		WebElement emailInput = driver.findElement(By.name("email"));
		emailInput.sendKeys("user@gmail.com");
		Thread.sleep(2000);
		WebElement passwordInput = driver.findElement(By.name("password"));
		passwordInput.sendKeys("userpassword123");
		Thread.sleep(2000);
		WebElement submitInput = driver.findElement(By.name("submit"));
		submitInput.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/login"));
		Thread.sleep(1000);
	}	
	
	@Test
	public void e_LogInSuccessTest() throws InterruptedException {
		WebElement emailInput = driver.findElement(By.name("email"));
		emailInput.sendKeys("dani@gmail.com");
		Thread.sleep(2000);
		WebElement passwordInput = driver.findElement(By.name("password"));
		passwordInput.sendKeys("daniela12");
		Thread.sleep(2000);
		WebElement submitInput = driver.findElement(By.name("submit"));
		Thread.sleep(1000);
		submitInput.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/home"));
	}
	
	@AfterClass
	public static void cleanUp() throws ClassNotFoundException, IOException, SQLException {
		// Conclude test
		driver.close();
	    driver.quit();
	}

}
