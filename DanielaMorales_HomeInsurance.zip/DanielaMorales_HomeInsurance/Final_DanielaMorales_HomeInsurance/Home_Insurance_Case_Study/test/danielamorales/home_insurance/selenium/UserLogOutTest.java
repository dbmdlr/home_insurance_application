package danielamorales.home_insurance.selenium;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class UserLogOutTest {

	static WebDriver driver;
	static UserRegistrationTest registration;
	static String quoteID;
	static Actions actions;
	@BeforeClass
	public static void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Student\\Desktop\\DanielaDB\\caseStudy\\chromedriver.exe");
		 driver = new ChromeDriver();
		 actions = new Actions(driver);
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 //registration = new UserRegistrationTest();
		 driver.get("http://localhost:8080/Home_Insurance_Case_Study/login");
	}

	@Test
	public void e_LogInSuccessTest() throws InterruptedException {
		WebElement emailInput = driver.findElement(By.name("email"));
		emailInput.sendKeys("dani@gmail.com");
		Thread.sleep(2000);
		WebElement passwordInput = driver.findElement(By.name("password"));
		passwordInput.sendKeys("daniela12");
		Thread.sleep(2000);
		WebElement submitInput = driver.findElement(By.name("submit"));
		Thread.sleep(1000);
		submitInput.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/home"));
	}
	
	@Test
	public void r_LogOutTest() throws InterruptedException {
		WebElement logOutLi = driver.findElement(By.cssSelector("a[href='./logout']"));
		Thread.sleep(1000);
		logOutLi.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/logout"));
	}

	@AfterClass
	public static void cleanUp() throws ClassNotFoundException, IOException, SQLException {
		// Conclude test
	    driver.quit();
	}
}
