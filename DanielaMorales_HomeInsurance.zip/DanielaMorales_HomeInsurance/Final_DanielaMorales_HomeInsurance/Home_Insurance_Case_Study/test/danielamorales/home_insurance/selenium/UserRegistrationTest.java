package danielamorales.home_insurance.selenium;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import danielamorales.home_insurance.helper.TestHelper;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class UserRegistrationTest {

	static WebDriver driver;
	static UserRegistrationTest registration;
	@BeforeClass
	public static void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Student\\Desktop\\DanielaDB\\caseStudy\\chromedriver.exe");
		 driver = new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 driver.get("http://localhost:8080/Home_Insurance_Case_Study/login");
	}
	
	@Test
	public void b_registrationLinkTest() throws InterruptedException {
		Thread.sleep(1000);
		WebElement linkRegistration = driver.findElement(By.cssSelector("a[class='forgot col-md-4']"));
		linkRegistration.click();
		Thread.sleep(2000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/registration"));
		
		//registration.registerUserFailTest();
		//registration.registerUserSuccessTest();
		
		//This works and helps to keep the flow and each test in separate
		//classes but the call is executed as a java method and not 
		//as a Junit test and doesn't display the test reports
	}
	
	@Test
	public void c_registerUserFailTest() throws InterruptedException {
		WebElement emailInput = driver.findElement(By.name("email-registration"));
		emailInput.sendKeys("user@gmail.com");
		Thread.sleep(2000);
		WebElement passwordInput = driver.findElement(By.name("password-registration"));
		passwordInput.sendKeys("userpassword321");
		Thread.sleep(2000);
		WebElement rpasswordInput = driver.findElement(By.name("rpassword-registration"));
		rpasswordInput.sendKeys("userpassword123");
		WebElement submitInput = driver.findElement(By.cssSelector("button[type=submit]"));
		submitInput.click();
		Thread.sleep(1000);
		
		WebElement errorDisplayed = driver.findElement(By.cssSelector("div[id='logInError']"));
		assertThat(errorDisplayed.isDisplayed(), is(true));
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/registration"));			
	}
	
	@Test
	public void d_registerUserSuccessTest() throws InterruptedException {
		WebElement emailInput = driver.findElement(By.name("email-registration"));
		emailInput.sendKeys("user@gmail.com");
		Thread.sleep(2000);
		WebElement passwordInput = driver.findElement(By.name("password-registration"));
		passwordInput.sendKeys("userpassword123");
		Thread.sleep(2000);
		WebElement rpasswordInput = driver.findElement(By.name("rpassword-registration"));
		rpasswordInput.sendKeys("userpassword123");
		WebElement submitInput = driver.findElement(By.cssSelector("button[type=submit]"));
		submitInput.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/welcome"));
		
		WebElement linkToLogin = driver.findElement(By.cssSelector("a[name='goBackLink']"));
		linkToLogin.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/login"));
	}
	
	
	@AfterClass
	public static void cleanUp() throws ClassNotFoundException, IOException, SQLException {
		// Conclude test
		String query = "DELETE FROM USER WHERE email='user@gmail.com';";
		TestHelper.deleteRecordHelper(query);
		driver.close();
	    driver.quit();
	}
}
