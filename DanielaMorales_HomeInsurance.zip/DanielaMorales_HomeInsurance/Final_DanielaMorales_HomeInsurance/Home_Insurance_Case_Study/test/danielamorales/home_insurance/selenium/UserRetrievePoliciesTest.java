package danielamorales.home_insurance.selenium;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.IsNot.not;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class UserRetrievePoliciesTest {

	static WebDriver driver;
	static String quoteID;
	static Actions actions;
	@BeforeClass
	public static void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Student\\Desktop\\DanielaDB\\caseStudy\\chromedriver.exe");
		 driver = new ChromeDriver();
		 actions = new Actions(driver);
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 //registration = new UserRegistrationTest();
		 driver.get("http://localhost:8080/Home_Insurance_Case_Study/login");
	}
	
	private boolean existsElement(String id) {
	    try {
	        driver.findElement(By.cssSelector(id));
	    } catch (NoSuchElementException e) {
	        return false;
	    }
	    return true;
	}
	
	@Test
	public void e_LogInSuccessTest() throws InterruptedException {
		WebElement emailInput = driver.findElement(By.name("email"));
		emailInput.sendKeys("jon@gmail.com");
		Thread.sleep(2000);
		WebElement passwordInput = driver.findElement(By.name("password"));
		passwordInput.sendKeys("jon12345");
		Thread.sleep(2000);
		WebElement submitInput = driver.findElement(By.name("submit"));
		Thread.sleep(1000);
		submitInput.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/home"));
	}
	
	@Test
	public void p_RetrievePoliciesLinkTest() throws InterruptedException {
		WebElement liPolicies = driver.findElement(By.cssSelector("a[href='./getPolicies']"));
		liPolicies.click();
		Thread.sleep(1000);
		assertThat(driver.findElement(By.cssSelector("i[class='fas fa-th-list']")).isDisplayed(), is(true));
	}
	
	@Test
	public void q_RetrievePoliciesTest() throws InterruptedException {
		if ( existsElement("table[class='table table-bordered']") ) {
			WebElement table = driver.findElement(By.cssSelector("table[class='table table-bordered']"));
			List<WebElement> row = table.findElements(By.tagName("tr"));
			assertThat(row.size(), is(not(0)));
		}else {
			assertThat(driver.findElement(By.cssSelector("div[class='alert alert-info']")).isDisplayed(), is(true));
		}
	}
	
	@AfterClass
	public static void cleanUp() throws ClassNotFoundException, IOException, SQLException {
		// Conclude test
	    driver.quit();
	}
}
