package danielamorales.home_insurance.selenium;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import danielamorales.home_insurance.helper.TestHelper;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class UserRetrieveQuote {
	static WebDriver driver;
	static Actions actions;
	static String quoteID;
	@BeforeClass
	public static void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Student\\Desktop\\DanielaDB\\caseStudy\\chromedriver.exe");
		 driver = new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 driver.get("http://localhost:8080/Home_Insurance_Case_Study/login");
		 actions = new Actions(driver);
	}
	
	@Test
	public void e_LogInSuccessTest() throws InterruptedException {
		WebElement emailInput = driver.findElement(By.name("email"));
		emailInput.sendKeys("dani@gmail.com");
		Thread.sleep(2000);
		WebElement passwordInput = driver.findElement(By.name("password"));
		passwordInput.sendKeys("daniela12");
		Thread.sleep(2000);
		WebElement submitInput = driver.findElement(By.name("submit"));
		Thread.sleep(1000);
		submitInput.click();
		Thread.sleep(1000);
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/home"));
	}
	
	@Test
	public void k_getQuoteNavBarTest() throws InterruptedException {
		WebElement liGetQuote = driver.findElement(By.cssSelector("a[href='./getQuote']"));
		liGetQuote.click();
		assertThat(driver.getCurrentUrl(), is("http://localhost:8080/Home_Insurance_Case_Study/getQuote"));
	}
	
	@Test
	public void l_selectQuoteTest() throws InterruptedException {
		WebElement table = driver.findElement(By.xpath("//table[@id='quotesTable']"));
		List<WebElement> row = table.findElements(By.tagName("tr"));
		assertThat(row.size(), is(notNullValue()));
		Thread.sleep(1000);
		
		quoteID =row.get(1).findElement(By.className("quoteID")).getText();
		row.get(1).findElement(By.cssSelector("input[type=submit]")).click();

		WebElement quoteIDHiddenInput = driver.findElement(By.name("quoteIDToBuy"));
		assertThat(quoteID, is(equalTo(quoteIDHiddenInput.getAttribute("value"))));
		Thread.sleep(1000);
	}
	
	@Test 
	public void m_buyingPolicyLinkTest() throws InterruptedException {
		WebElement buyPolicyBtn = driver.findElement(By.cssSelector("button[type=submit]"));
		buyPolicyBtn.click();
		Thread.sleep(1000);
		
		WebElement text = driver.findElement(By.cssSelector("a[target='_blank']"));
		assertThat(text.isDisplayed(), is(true));
	}
	
	@Test 
	public void n_buyingPolicyFailTest() throws InterruptedException {
		driver.findElement(By.cssSelector("input[name='startDate']")).sendKeys("2018-12-12");
		WebElement checkbox = driver.findElement(By.cssSelector("input[type='checkbox']"));
		actions.moveToElement(checkbox).click().perform();
		Thread.sleep(1000);
		
		WebElement buyPolicyBtn = driver.findElement(By.cssSelector("button[id='buyPolicyBtn']"));
		buyPolicyBtn.click();
		Thread.sleep(1000);
		
		WebElement dangerAlert = driver.findElement(By.id("alertStartDateError"));
		assertThat(dangerAlert.isDisplayed(), is(true));
	}
	
	@Test 
	public void o_buyingPolicySuccessTest() throws InterruptedException {
		driver.findElement(By.cssSelector("input[name='startDate']")).sendKeys("2018-10-05");
		WebElement checkbox = driver.findElement(By.cssSelector("input[type='checkbox']"));
		actions.moveToElement(checkbox).click().perform();
		Thread.sleep(1000);
		
		WebElement buyPolicyBtn = driver.findElement(By.cssSelector("button[id='buyPolicyBtn']"));
		buyPolicyBtn.click();
		Thread.sleep(1000);
		
		assertThat( driver.findElement(By.id("startDateDisplay")).getAttribute("value"), is(equalTo("2018-10-05")));
	}
	
	@AfterClass
	public static void cleanUp() throws ClassNotFoundException, IOException, SQLException {
		// Conclude test
		String query = "DELETE FROM POLICY WHERE quote_id="+quoteID+";";
		TestHelper.deleteRecordHelper(query);
	    driver.quit();
	}

}
