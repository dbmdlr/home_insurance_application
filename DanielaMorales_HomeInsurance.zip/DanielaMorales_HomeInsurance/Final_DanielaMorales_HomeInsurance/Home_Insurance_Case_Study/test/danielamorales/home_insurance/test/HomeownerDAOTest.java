package danielamorales.home_insurance.test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static org.hamcrest.core.IsEqual.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.core.Is.is;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import danielamorales.home_insurance.dao.HomeownerDAO;
import danielamorales.home_insurance.helper.TestHelper;
import danielamorales.home_insurance.model.Homeowner;

public class HomeownerDAOTest {
	static HomeownerDAO ho_dao;
	static Homeowner homeowner;
	static Homeowner ho;
	static Integer idToDelete;
	static Integer idToSearch;
	
	@BeforeClass
	public static void setUp() throws Exception {
		ho_dao = new HomeownerDAO();
		homeowner = new Homeowner();
		idToSearch = 71;
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date parsed = format.parse("1990-10-12");
        java.sql.Date sql = new java.sql.Date(parsed.getTime());
		ho = new Homeowner("Jon", "Balderas", sql, 8,"152338888", "jon@gmail.com");
	}

	@Test
	public void insertHomeownerTestRetiredFail(){
		try {
			ho_dao.postHomeowner(ho);
		} catch (ClassNotFoundException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
	@Test
	public void insertLocationTestSuccess() throws ClassNotFoundException, SQLException, IOException{
		ho.setRetired(0);
		idToDelete = ho_dao.postHomeowner(ho);
		assertThat(idToDelete, is(notNullValue()));
	}
	
	@Test
	public void getLocationTest() throws ClassNotFoundException, SQLException, IOException{
		 homeowner = ho_dao.getHomeowner(idToSearch);
		 assertThat(homeowner, is(notNullValue()));
		 assertThat(homeowner.getFirstname(), is(equalTo("Giovanni")));
	}
	@AfterClass
	public static void CleanUp() throws ClassNotFoundException, IOException, SQLException {
		String query = "DELETE FROM homeowner WHERE homeowner_id="+idToDelete+";";
		assertThat(TestHelper.deleteRecordHelper(query), is(true));
	}

}
