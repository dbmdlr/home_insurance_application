package danielamorales.home_insurance.test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.not;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import danielamorales.home_insurance.dao.LocationDAO;
import danielamorales.home_insurance.helper.TestHelper;
import danielamorales.home_insurance.model.Location;
import danielamorales.home_insurance.model.Quote;
import danielamorales.home_insurance.model.State;

public class LocationDAOTest {
	static LocationDAO lo_dao; 
	static Location location;
	static Location lo;
	static Integer idToDelete;
	static Integer idToSearch;
	static String emailToSearch;
	
	@BeforeClass
	public static void setUp() throws Exception {
		lo_dao = new LocationDAO();
		location = new Location();
		lo = new Location(null, "address for test", null, "Dallas", 44, 75254,
				"Single-Family Home", "Primary", "jon@gmail.com");
		idToSearch = 57;
		emailToSearch = "dani@gmail.com";
	}

	@Test
	public void insertLocationTestResidenceTypeFail(){
		lo.setResidence_type("My Residence");
		try {
			lo_dao.postLocation(lo);
		} catch (ClassNotFoundException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void insertLocationTestResidenceUseFail(){
		lo.setResidence_type("Single-Family Home");
		lo.setResidence_use("My Residence");
		try {
			lo_dao.postLocation(lo);
		} catch (ClassNotFoundException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void insertLocationTestSuccess() throws ClassNotFoundException, SQLException, IOException{
		lo.setResidence_type("Single-Family Home");
		lo.setResidence_use("Primary");
		idToDelete = lo_dao.postLocation(lo);
		assertThat(idToDelete, is(notNullValue()));
	}
	
	@Test
	public void getLocationTest() throws ClassNotFoundException, SQLException, IOException{
		 location = lo_dao.getLocation(idToSearch);
		 assertThat(location, is(notNullValue()));
		 assertThat(location.getCity(), is(equalTo("Dallas")));
	}
	
	@Test
	public void getAllLocationTest() throws ClassNotFoundException, SQLException, IOException{
		HashMap<Location, HashMap<Quote, State>> locationHash = lo_dao.getAllLocations(emailToSearch);
		 assertThat(locationHash, is(notNullValue()));
		 assertThat(locationHash.size(), is(not(0)));
		 assertThat(locationHash.isEmpty(), is(false));
	
		 for (HashMap.Entry<Location, HashMap<Quote, State>> entry: locationHash.entrySet()) {
			 assertThat(entry.getKey(), is(instanceOf(Location.class)));
			 assertThat(entry.getValue(), is(instanceOf(HashMap.class)));
			 for (HashMap.Entry<Quote, State> inner: entry.getValue().entrySet()) {
				assertThat(inner.getKey(), is(instanceOf(Quote.class)));
				assertThat(inner.getValue(), is(instanceOf(State.class)));
			 }
		 }
	}
	
	@AfterClass
	public static void CleanUp() throws ClassNotFoundException, IOException, SQLException {
		String query = "DELETE FROM location WHERE location_id="+idToDelete+";";
		assertThat(TestHelper.deleteRecordHelper(query), is(true));
	}

}
