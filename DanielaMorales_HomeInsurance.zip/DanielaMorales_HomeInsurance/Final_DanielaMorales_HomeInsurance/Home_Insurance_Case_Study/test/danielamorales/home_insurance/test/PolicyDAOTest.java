package danielamorales.home_insurance.test;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.beans.HasProperty.hasProperty;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import danielamorales.home_insurance.dao.PolicyDAO;
import danielamorales.home_insurance.helper.TestHelper;
import danielamorales.home_insurance.model.Policy;

public class PolicyDAOTest {
	static PolicyDAO po_dao;
	static Policy policy;
	static List<Policy> po;
	static Integer policyID;
	static String emailToSearch;
	
	@BeforeClass
	public static void setUp() throws Exception {

		po_dao = new PolicyDAO();
		policy = new Policy();
		policy.setStart_date(TestHelper.formatDate("2018-08-25"));
		policy.setExpiration_date(TestHelper.formatDate("2019-08-25"));
		policy.setPolicy_term(1);
		policy.setActive(true);
		policy.setQuote_id(56);
		policy.setUser_email("dani@gmail.com");
		
		po = new ArrayList<Policy>();
		emailToSearch="dani@gmail.com";
	}

	@Test
	public void insertPolicyTest() throws ClassNotFoundException, SQLException, IOException {
		policyID = po_dao.postPolicy(policy);
		assertThat(policyID, is(notNullValue()));
	}
	
	@Test
	public void getAllPoliciesTest() throws ClassNotFoundException, SQLException, IOException {
		po = po_dao.getAllPolicies(emailToSearch);
		assertThat(po, is(notNullValue()));
		assertThat(po.size(), is(not(0)));
		for (int i=0; i<po.size(); i++) {
			assertThat(po.get(i), hasProperty("policy_term"));
			assertThat(po.get(i), hasProperty("start_date"));
		}
	}
	
	//The validations for renew and cancel policy are made directly on the servlet.
	//Testing those methods here will not reflect the correct flow,
	//just how to update in the DB. This test will be done with Selenium, that will demonstrate
	// the actual flow.
	
	@AfterClass
	public static void CleanUp() throws ClassNotFoundException, IOException, SQLException {
		String query = "DELETE FROM policy WHERE policy_key="+policyID+";";
		assertThat(TestHelper.deleteRecordHelper(query), is(true));
	}

}
