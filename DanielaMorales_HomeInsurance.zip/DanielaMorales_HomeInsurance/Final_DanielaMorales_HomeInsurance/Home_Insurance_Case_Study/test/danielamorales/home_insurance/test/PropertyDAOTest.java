package danielamorales.home_insurance.test;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import danielamorales.home_insurance.dao.LocationDAO;
import danielamorales.home_insurance.dao.PropertyDAO;
import danielamorales.home_insurance.helper.TestHelper;
import danielamorales.home_insurance.model.Location;
import danielamorales.home_insurance.model.Property;

public class PropertyDAOTest {
	static PropertyDAO pro_dao;
	static LocationDAO lo_dao;
	static Property property;
	static Property pro;
	static Integer idToDelete;
	static Integer idToSearch;
	static Integer locationIdToDelete;
	static Location lo;
	
	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();
	
	@BeforeClass
	public static void setUp() throws Exception {
		//First: insert location
		lo = new Location(null, "address for test", null, "Dallas", 44, 75254,
				"Single-Family Home", "Primary", "jon@gmail.com");
		lo_dao = new LocationDAO();
		locationIdToDelete = lo_dao.postLocation(lo);
		
		pro_dao = new PropertyDAO();
		property = new Property();
		idToSearch = 71;

		pro = new Property(2010, 252.55, "Concrete",
				"Attached", "1", "2", 0,
				"1 Story", "jon@gmail.com", locationIdToDelete, 25500.20);
		
	}

	@Test
	public void insertPropertyTestGarageTypeFail() {
		pro.setGarage_type("Other");
		try {
			pro_dao.postProperty(pro);
		} catch (ClassNotFoundException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void insertPropertyTestRoofMaterialFail() {
		pro.setGarage_type("Attached");
		pro.setRoof_material("Other material");
		try {
			pro_dao.postProperty(pro);
		} catch (ClassNotFoundException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void insertPropertyTestBathNumberFail() {
		pro.setGarage_type("Attached");
		pro.setRoof_material("Concrete");
		pro.setBaths_number("Only 1"); 
		try {
			pro_dao.postProperty(pro);
		} catch (ClassNotFoundException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void insertPropertySuccess() throws ClassNotFoundException, SQLException, IOException {
		pro.setGarage_type("Attached");
		pro.setRoof_material("Concrete");
		pro.setBaths_number("More"); 
		idToDelete = pro_dao.postProperty(pro);
		assertThat(idToDelete, is(notNullValue()));
	}
	
	@AfterClass
	public static void CleanUp() throws ClassNotFoundException, IOException, SQLException {
		String query = "DELETE FROM location WHERE location_id="+locationIdToDelete+";";
		assertThat(TestHelper.deleteRecordHelper(query), is(true));
	}
}
