package danielamorales.home_insurance.test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.beans.HasProperty.hasProperty;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import danielamorales.home_insurance.dao.QuoteDAO;
import danielamorales.home_insurance.helper.TestHelper;
import danielamorales.home_insurance.model.Quote;

public class QuoteDAOTest {
	static QuoteDAO qu_dao;
	static Integer quoteID;
	static Quote quote;
	static Integer quoteToSearch;
	static Quote q;
	static String emailToSearch;
	static List<Quote> quoteList;
	
	@BeforeClass
	public static void setUp() throws Exception {
		qu_dao = new QuoteDAO();
		quote = new Quote(null, 23.453347999999995, 53101.92, 5310.192, 31861.152, 10620.384, 5000.00,	1500.00, "dani@gmail.com",	68,	56,	57);
		q = new Quote();
		quoteToSearch = 55;
		emailToSearch = "dani@gmail.com";
	}

	@Test
	public void insertQuoteTest() throws ClassNotFoundException, SQLException, IOException {
		quoteID = qu_dao.postQuote(quote);
		assertThat(quoteID, is(notNullValue()));
	}
	
	@Test
	public void getQuoteTest() throws ClassNotFoundException, SQLException, IOException {
		q = qu_dao.getQuote(quoteToSearch);
		assertThat(q, is(notNullValue()));
		assertThat(q, is(instanceOf(Quote.class)));
		assertThat(q.getUser_email(), is(equalTo("dani@gmail.com")));
	}
	
	@Test
	public void getAllQuotesTest() throws ClassNotFoundException, SQLException, IOException {
		quoteList = qu_dao.getAllQuotes(emailToSearch);
		assertThat(quoteList, is(notNullValue()));
		assertThat(quoteList.size(), is(not(0)));
		for (int i=0; i<quoteList.size(); i++) {
			assertThat(quoteList.get(i), hasProperty("dwelling_coverage"));
			assertThat(quoteList.get(i), hasProperty("detached_structures"));
		}
	}
	
	@AfterClass
	public static void CleanUp() throws ClassNotFoundException, IOException, SQLException {
		String query = "DELETE FROM quote WHERE quote_id="+quoteID+";";
		assertThat(TestHelper.deleteRecordHelper(query), is(true));
	}
}
