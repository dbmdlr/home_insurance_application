package danielamorales.home_insurance.test;

import static org.junit.Assert.*;
import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsEqual.equalTo;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collection;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import danielamorales.home_insurance.dao.UserDAO;
import danielamorales.home_insurance.helper.TestHelper;
import danielamorales.home_insurance.model.User;

@RunWith(Parameterized.class)
public class UserDAOTest {
	static UserDAO user_dao;
	
	//Parameters
	@Parameterized.Parameter (value=0)
    public static User user;
	
	@Parameterized.Parameter (value=1)
    public Boolean expected_outcome;
	
	@Parameterized.Parameter (value=2)
    public Boolean expected_outcome_admin;
	
	//Creating test data
    @Parameterized.Parameters
    public static Collection<Object[]> data() {
        Object[][] dataValues = new Object[][] { 
        	{new User("joe2@yahoo.com", "password78028"), true, false}
        	
        	
        };
        return Arrays.asList(dataValues);
    }
	
	@BeforeClass
	public static void setUp() throws Exception {
		user_dao = new UserDAO();
	}
	
	@Test
	public void userRegistrationTest() throws ClassNotFoundException, SQLException, IOException {
		Integer registrationResult = user_dao.registerUser(user);
		assertThat(registrationResult, is(notNullValue()));
		assertThat(registrationResult, is(equalTo(1)));
	}
	
	@Test
	public void LogInAdminTest() throws ClassNotFoundException, SQLException, IOException {
		Boolean logInAdminResult = user_dao.adminLogIn(user);
		assertThat(logInAdminResult, is(notNullValue()));
		assertThat(logInAdminResult, is(equalTo(expected_outcome_admin)));
	}
	
	@Test
	public void LogInTest() throws ClassNotFoundException, SQLException, IOException {
		Boolean logInResult = user_dao.logIn(user);
		assertThat(logInResult, is(notNullValue()));
		assertThat(logInResult, is(equalTo(expected_outcome)));
	}
	
	@AfterClass
	public static void CleanUp() throws ClassNotFoundException, IOException, SQLException {
		String query = "DELETE FROM user WHERE email='"+user.getEmail()+"';";
		assertThat(TestHelper.deleteRecordHelper(query), is(true));
	}

}
